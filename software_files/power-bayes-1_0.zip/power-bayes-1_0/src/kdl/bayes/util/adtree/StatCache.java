/**
 * $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 *
 */

package kdl.bayes.util.adtree;

import java.util.Map;

public interface StatCache {

    public double getCount(Map<Integer, Integer> query, int varIdx);

}

