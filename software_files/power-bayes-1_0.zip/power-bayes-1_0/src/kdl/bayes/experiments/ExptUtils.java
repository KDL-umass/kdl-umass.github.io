/**
 * $Id: ExptUtils.java 286 2009-09-23 19:35:24Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 */

package kdl.bayes.experiments;

import kdl.bayes.PowerBayesNet;
import kdl.bayes.util.Assert;
import kdl.bayes.util.Util;
import org.apache.log4j.Logger;
import weka.core.Instances;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.*;

/**
 * ExptUtils
 */
public class ExptUtils {
    protected static Logger log = Logger.getLogger(ExptUtils.class);

    public static Set<String> arrayToSet(String[] strings) {
        Set<String> set = new HashSet<String>();
        for (int i = 0; i < strings.length; i++) {
            set.add(strings[i]);
        }
        return set;
    }

    public static boolean[][] convertToMatrix(Map<String, Set<String>> varToCPC, Instances instances) {
        int numVariables = instances.numAttributes();
        boolean[][] neighbors = new boolean[numVariables][numVariables];
        for (Iterator<String> iterator = varToCPC.keySet().iterator(); iterator.hasNext();) {
            String varName = iterator.next();
            int varIdx = instances.attribute(varName).index();
            for (Iterator<String> cpcIterator = varToCPC.get(varName).iterator(); cpcIterator.hasNext();) {
                String nbrName = cpcIterator.next();
                int nbrIdx = instances.attribute(nbrName).index();
                neighbors[varIdx][nbrIdx] = true;
            }
        }

        for (int i = 0; i < neighbors.length; i++) {
            for (int j = 0; j < neighbors[i].length; j++) {
                Assert.condition(neighbors[i][j] == neighbors[j][i], "CPCs are not symmetrical! " + i + " " + j);
            }
        }
        return neighbors;
    }

    public static Map<String, Set<String>> loadCPC(String prefix, String cpcType, int trainIndex, int sampleSize, double dataThreshold) {
        String fileName = prefix + "cpc." + cpcType + "." + trainIndex + "." + sampleSize + "." + dataThreshold + ".txt";
        if (Double.compare(dataThreshold, -1.0) == 0) {
            fileName = prefix + "cpc." + cpcType + "." + trainIndex + "." + sampleSize + ".txt";
        }

        Map<String, Set<String>> varToCPC = new HashMap<String, Set<String>>();
        String fileStr = Util.readStringFromFile(new File(fileName));
        String[] lines = fileStr.split("\n");
        for (int i = 0; i < lines.length; i++) {
            String[] parts = lines[i].split(":");
            String targetName = parts[0];
            String[] cpcVars;
            if (parts.length == 2) {
                cpcVars = parts[1].split(",");
            } else if (parts.length == 1) {
                cpcVars = new String[0];
            } else {
                throw new IllegalArgumentException("Cannot parse line " + lines[i]);
            }
            Set<String> cpc = arrayToSet(cpcVars);
            varToCPC.put(targetName, cpc);
        }
        log.debug("Loaded CPC file: " + fileName);
        return varToCPC;
    }

    public static Map<String, Set<String>> loadMatrixCPC(String prefix, String cpcType, int trainIndex, int sampleSize, double dataThreshold, PowerBayesNet trueBn) {
        String fileName = prefix + "cpc." + cpcType + "." + trainIndex + "." + sampleSize + "." + dataThreshold + ".txt";
        if (Double.compare(dataThreshold, -1.0) == 0) {
            fileName = prefix + "cpc." + cpcType + "." + trainIndex + "." + sampleSize + ".txt";
        }

        Map<String, Set<String>> varToCPC = new HashMap<String, Set<String>>();
        String fileStr = Util.readStringFromFile(new File(fileName));
        String[] lines = fileStr.split("\n");

        for (int i = 0; i < lines.length; i++) {
            String[] parts = lines[i].split("\t");
            String targetName = trueBn.getNodeName(i);
            Set<String> cpc = new HashSet<String>();

            for (int j = 0; j < parts.length; j++) {
                Double part = Double.parseDouble(parts[j]);
                if (Double.compare(part, 1.0) == 0) {
                    //log.info("Adding var " + j + " to " + i);
                    cpc.add(trueBn.getNodeName(j));
                }
            }
            varToCPC.put(targetName, cpc);
        }
        log.debug("Loaded CPC file: " + fileName);
        return varToCPC;
    }

    public static void saveCPC(String prefix, String cpcType, int trainIndex, int sampleSize, double dataThreshold, PowerBayesNet bn, boolean[][] skeleton) {

        String outFilename = prefix + "cpc." + cpcType + "." + trainIndex + "." + sampleSize + "." + dataThreshold + ".txt";
        if (Double.compare(dataThreshold, -1.0) == 0) {
            outFilename = prefix + "cpc." + cpcType + "." + trainIndex + "." + sampleSize + ".txt";
        }

        log.info("Saving skeleton to file:" + outFilename);
        try {
            PrintWriter outfile = new PrintWriter(new FileWriter(outFilename));

            int size = bn.getNrOfNodes();

            for (int i = 0; i < size; i++) {
                String targetName = bn.getNodeName(i);
                String s = targetName + ":";
                for (int j = 0; j < size; j++) {
                    if (skeleton[i][j]) {
                        String neighborName = bn.getNodeName(j);
                        s += neighborName + ",";
                    }
                }
                if (s.endsWith(",")) {
                    s = s.substring(0, s.length() - 1);
                }
                outfile.println(s);
            }
            outfile.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String dagToString(boolean[][] dag) {
        String str = "Begin DAG (" + dag.length + "):\n";
        for (int i = 0; i < dag.length; i++) {
            for (int j = 0; j < dag[i].length; j++) {
                str += (dag[i][j] ? "1 " : "0 ");
            }
            str += "\n";
        }
        return str + "end DAG";
    }

}
