/**
 * $Id: MMPC.java 286 2009-09-23 19:35:24Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 */

package kdl.bayes.skeleton;

import kdl.bayes.skeleton.util.*;
import kdl.bayes.util.Assert;
import kdl.bayes.util.StatUtil;
import org.apache.log4j.Logger;

import java.util.*;

/**
 * MMPC (Note: this is actually {\bar MMPC} from the MMHC paper
 * For details see MMHC
 * Author: mhay
 */
public class MMPC {
    protected static Logger log = Logger.getLogger(MMPC.class);

    public final double pValueThreshold = 0.05;

    protected int numVariables;
    protected BayesData data;
    protected int targetIdx;
    protected List<Integer> currentCPC;

    protected List<Integer> remainingVariables;
    protected List<Integer> incomparableVariables;  // variables for which not enough data to compute even pairwise association
    protected int lastCandidate;
    protected Map<Integer, double[]> cachedScore;

    protected int maxConditioningSetSize = -1;
    protected boolean addIncomparablePairwise = false;

    public ThresholdModule threshModule;

    private int buildCPCsize = 0;

    public MMPC(ThresholdModule threshold) {
        Assert.notNull(threshold, "Threshold object must be defined.");
        threshModule = threshold;
        maxConditioningSetSize = -1;
        addIncomparablePairwise = false;
    }

    public MMPC(ThresholdModule threshold, int maxConditioningSetSize) {
        Assert.notNull(threshold, "Threshold object must be defined.");
        threshModule = threshold;
        this.maxConditioningSetSize = maxConditioningSetSize;
        this.addIncomparablePairwise = false;
    }

    public MMPC(ThresholdModule threshold, boolean addIncomparablePairwise) {
        Assert.notNull(threshold, "Threshold object must be defined.");
        threshModule = threshold;
        maxConditioningSetSize = -1;
        this.addIncomparablePairwise = addIncomparablePairwise;
    }

    public MMPC(ThresholdModule threshold, int maxConditioningSetSize, boolean addIncomparablePairwise) {
        Assert.notNull(threshold, "Threshold object must be defined.");
        threshModule = threshold;
        this.maxConditioningSetSize = maxConditioningSetSize;
        this.addIncomparablePairwise = addIncomparablePairwise;
    }

    /**
     * Does the heavy lifting, one variable at a time
     *
     * @param data
     * @param targetIdx
     * @param xIdxsToInclude
     * @param xIdxsToExclude
     * @return
     */
    public List<Integer> computeCPC(BayesData data, int targetIdx, List<Integer> xIdxsToInclude,
                                    List<Integer> xIdxsToExclude) {

        this.data = data;
        this.targetIdx = targetIdx;
        numVariables = data.numAttributes();
        Assert.condition(targetIdx >= 0 && targetIdx < numVariables, "Invalid target index");

        log.debug("TARGET:" + data.getName(targetIdx));
        log.debug("INCLUDE: " + data.getNames(xIdxsToInclude));
        log.debug("EXCLUDE: " + data.getNames(xIdxsToExclude));

        currentCPC = new ArrayList<Integer>(xIdxsToInclude);

        remainingVariables = new ArrayList<Integer>();
        for (int varIdx = 0; varIdx < numVariables; varIdx++) {
            remainingVariables.add(varIdx);
        }
        remainingVariables.remove(targetIdx);
        remainingVariables.removeAll(xIdxsToInclude);
        remainingVariables.removeAll(xIdxsToExclude);

        incomparableVariables = new ArrayList<Integer>();
        cachedScore = new HashMap<Integer, double[]>();
        lastCandidate = -1;

        log.debug("\tbuilding cpc for target " + data.getName(targetIdx) +
                " (|cpc| = " + currentCPC.size() + "; |remaining| = " + remainingVariables.size() + ")");
        buildCPC();
        buildCPCsize = currentCPC.size();
        log.debug("\tpruning cpc " +
                " (|cpc| = " + currentCPC.size() + ")");
        pruneCPC();

        currentCPC.addAll(incomparableVariables);

        log.debug("\tfinished cpc: " + data.getNames(currentCPC) +
                " (|cpc| = " + currentCPC.size() + ")");

        return currentCPC;
    }

    public List<Integer> computeCPC(BayesData data, int targetIdx) {
        return computeCPC(data, targetIdx, new ArrayList<Integer>(), new ArrayList<Integer>());
    }

    protected void buildCPC() {
        boolean foundCandidate = true;
        while (foundCandidate) {
            int nextCandidate = maxMinHeuristic();
            if (nextCandidate < 0) {
                foundCandidate = false;
            } else {
                log.debug("\t ...adding " + data.getName(nextCandidate));
                currentCPC.add(nextCandidate);
                log.debug("CURRENT CPC: " + data.getNames(currentCPC));
                remainingVariables.remove(new Integer(nextCandidate));
                log.debug("REMAINING: " + data.getNames(remainingVariables));
                lastCandidate = nextCandidate;
            }
        }
    }

    protected boolean containsSubset(Set<Integer> set, Set<Set<Integer>> subsets) {
        for (Set<Integer> subset : subsets) {
            if (set.containsAll(subset)) {
                return true;
            }
        }
        return false;
    }

    protected int[] convert(Set<Integer> intSet) {
        int[] ints = new int[intSet.size()];
        int idx = 0;
        for (Iterator<Integer> iterator = intSet.iterator(); iterator.hasNext();) {
            ints[idx] = iterator.next();
            idx++;
        }
        return ints;
    }

    /**
     * Simple method to enforce a maximum on the conditioning set size.
     *
     * @param cpc
     * @return
     */
    protected int getMaxSize(List<Integer> cpc) {
        if (maxConditioningSetSize < 0 || cpc.size() < maxConditioningSetSize) {
            return cpc.size();
        }
        return maxConditioningSetSize;
    }

    public int getBuildCPCSize() {
        return buildCPCsize;
    }

    public int getNumStatisticalCalls() {
        return data.getNumStatisticalCalls();
    }

    /**
     * From the remaining varibles, this method selects the variable
     * that is most strongly associated with the target, according to
     * the maxMinHeuristic.  Returns -1 if no such variable.
     * <p/>
     * Modifies both currentCPC and remainingVariables
     *
     * @return index of best variable
     */
    protected int maxMinHeuristic() {
        double maxScore = 0;        // score must be at least zero
        double maxGScore = 0;
        double maxES = 0;
        int maxIdx = -1;
        double maxSizeZ = 0;
        double maxRanTest = 0;

        Assert.condition(!remainingVariables.remove(new Integer(targetIdx)), "Target should not have been in remaining variables.");
        Assert.condition(!remainingVariables.removeAll(currentCPC), "current CPC should not have been in remaining variables.");

        for (Iterator<Integer> iterator = remainingVariables.iterator(); iterator.hasNext();) {
            int xIdx = iterator.next();
            double pValScore = 0;
            double gScore = 0;
            double es = 0;
            double sizeZ = 0;
            double ranTest = 0;
            try {
                double[] scoreArr = minAssoc(xIdx);
                pValScore = scoreArr[0];
                gScore = scoreArr[1];
                es = scoreArr[2];
                sizeZ = scoreArr[3];
                ranTest = scoreArr[4];
                if (Double.compare(pValScore, maxScore) > 0 ||
                        (Double.compare(pValScore, maxScore) == 0 && Double.compare(es, maxES) > 0)) {
                    maxIdx = xIdx;
                    maxScore = pValScore;
                    maxGScore = gScore;
                    maxES = es;
                    maxSizeZ = sizeZ;
                    maxRanTest = ranTest;
                }
                if (StatUtil.equalDoubles(pValScore, 0)) {
                    iterator.remove();  // no need to consider this variable again
                }
            } catch (SparseDataException e) {
                log.debug(e);
                if (e instanceof ZeroDOFException) {
                    log.debug("Adding ZeroDOF variable" + data.getName(xIdx) + " to " + data.getName(targetIdx));
                    incomparableVariables.add(xIdx);
                }

                if (addIncomparablePairwise) {
                    log.debug("LOW POWER: Adding variable" + data.getName(xIdx) + " to " + data.getName(targetIdx));
                    incomparableVariables.add(xIdx);
                }
                iterator.remove();
            }
        }
        if (maxIdx > -1) {
            String type = "add";
            if (Double.compare(maxRanTest, 0.0) == 0) {
                type = "add-default";
            }
            log.debug("DECISION: mode=build type=" + type + " target=" + data.getName(targetIdx) + " dof=" + data.traditionalDof + " tableSize=" + data.tableSize + " x=" + data.getName(maxIdx) + " es=" + maxES + " sizeZ=" + maxSizeZ + " n=" + data.sampleSize);
        }
        return maxIdx;
    }

    protected double[] minAssoc(int xIdx) throws SparseDataException {
        double[] minScore;

        List<Integer> copyCPC = new ArrayList<Integer>(currentCPC);
        if (lastCandidate >= 0) {
            Assert.condition(copyCPC.contains(lastCandidate),
                    "Last candidate " + lastCandidate + " should be in current CPC " + copyCPC);
            //copyCPC.remove(new Integer(lastCandidate));  //not sure why this line is in here, no change in the results but removing it for efficiency
            Assert.condition(cachedScore.containsKey(xIdx), "No score for " + xIdx);
            minScore = cachedScore.get(xIdx);
        } else {
            minScore = new double[]{Double.MAX_VALUE, Double.MAX_VALUE, 0, 0, 0};
        }

        Set<Set<Integer>> zeroDofSubsets = new HashSet<Set<Integer>>();

        for (int setSize = 0; setSize <= getMaxSize(copyCPC); setSize++) {
            // for each subset of the Zs of size setSize, compute
            // association measure
            Iterator iter = new PowerSetIterator(copyCPC, setSize);
            boolean enoughData = false;
            while (iter.hasNext()) {
                Set<Integer> subset = (Set<Integer>) iter.next();
                if (lastCandidate >= 0 && setSize < getMaxSize(copyCPC)) {
                    subset.add(lastCandidate);  // only consider subsets that involve the last candidate
                }

                if (containsSubset(subset, zeroDofSubsets)) {
                    continue;
                }

                int[] zIdxs = convert(subset);
                data.setIndexes(xIdx, targetIdx, zIdxs);
                if (!threshModule.enoughData(data)) {
                    // if the Zs are empty and there is not enough data, then these
                    // two variables cannot be compared (Can't even run pairwise test!).
                    if (zIdxs.length == 0) {
                        throw new SparseDataException("Not enough data to compute *any* association between "
                                + data.getName(xIdx) + " and " + data.getName(targetIdx));
                    }
                    log.debug("DID NOT RUN:" + "(" + data.getName(targetIdx) + ";" + data.getName(xIdx) + "|" + data.getNames(zIdxs) + ")");
                    continue;
                }

                data.computeStats();

                // check for zero degrees of freedom
                if (data.hasZeroDof()) {
                    String zVars = "";
                    for (int i = 0; i < zIdxs.length; i++) {
                        zVars += data.getName(zIdxs[i]) + " ";
                    }
                    log.debug("dof=0 for X=" + data.getName(xIdx) + " T=" + data.getName(targetIdx) + " Z=" + zVars);
                    // the conditioning set is empty, if it cannot run a stat test comparing
                    // two variables without a conditioning set, then surely add variables
                    // to the conditioning set won't change things, so stop now
                    //if (zIdxs.length == 0) {
                    //    throw new ZeroDOFException("dof=0 between "
                    //            + data.getName(xIdx) + " and " + data.getName(targetIdx) + " with empty CPC.");
                    //}
                    // if the z subset has a single conditioning variable, then there is
                    // no point in looking at any subset that contains this variable
                    //else {
                        zeroDofSubsets.add(subset);
                    //}
                    //Following TETRAD, we conclude independence
                    return new double[]{0, 0, 0, setSize, 1};
                    //continue;
                }

                double[] score = data.assoc(pValueThreshold);
                if (Double.compare(score[0], minScore[0]) < 0) {
                    minScore = score;

                    if (StatUtil.equalDoubles(0, minScore[0])) {
                        log.debug("DECISION: mode=build type=remove target=" + data.getName(targetIdx) + " x=" + data.getName(xIdx) + " dof=" + data.traditionalDof + " tableSize=" + data.tableSize + " es=" + minScore[2] + " sizeZ=" + zIdxs.length + " n=" + data.sampleSize);
                        return new double[]{0, 0, 0, setSize, 1};
                    }

                }

                enoughData = true;
            }
            // if there is not enough data at this set size, there won't be at any
            // higher set size
            if (!enoughData) {
                log.debug("FINISHED TESTING:" + "(" + data.getName(targetIdx) + ";" + data.getName(xIdx) + ")");
                break;
            }
        }

        // update cache and put last candidate back into CPC
        cachedScore.put(xIdx, minScore);
        return minScore;
    }

    protected void pruneCPC() {
        // create copy
        Set<Integer> variables = new HashSet<Integer>(currentCPC);
        for (Integer xIdx : variables) {
            currentCPC.remove(xIdx);
            // try to find a subset Z of CPCs such that target T is
            // independent of variable X when conditioned on Z
            // stop search as soon as you can show independence
            Set<Set<Integer>> zeroDofSubsets = new HashSet<Set<Integer>>();
            boolean isIndependent = false;
            double[] lastScore = new double[]{0, 0, 0, 0, 0};
            String type = "keep";

            for (int setSize = 1; setSize <= getMaxSize(currentCPC) && !isIndependent; setSize++) {
                log.debug("\tpruning with cpc size " + setSize);
                Iterator iter = new PowerSetIterator(currentCPC, setSize);
                boolean enoughData = false;
                while (!isIndependent && iter.hasNext()) {
                    Set<Integer> subset = (Set<Integer>) iter.next();
                    if (containsSubset(subset, zeroDofSubsets)) {
                        continue;
                    }
                    int[] cpcSubset = convert(subset);
                    data.setIndexes(xIdx, targetIdx, cpcSubset);

                    if (!threshModule.enoughData(data)) {
                        continue;
                    }

                    data.computeStats();

                    if (data.hasZeroDof()) {
                        zeroDofSubsets.add(subset);
                    }

//                    if (!data.enoughData()) {
//                        continue;
//                    }

                    double[] score = data.assoc(pValueThreshold);
                    lastScore = score;
                    isIndependent = StatUtil.equalDoubles(score[0], 0);
                    if (isIndependent) {
                        log.debug("DECISION: mode=prune type=remove target=" + data.getName(targetIdx) + " x=" + data.getName(xIdx) + " dof=" + data.traditionalDof + " tableSize=" + data.tableSize + " es=" + score[2] + " sizeZ=" + score[3] + " n=" + data.sampleSize);
                        log.debug("\t...removing candidate " + data.getName(xIdx) +
                                " because " + data.getName(targetIdx) + " ; " + data.getName(xIdx) +
                                " | " + data.getNames(cpcSubset)
                        );
                    }

                    enoughData = true;
                }
                // if there is not enough data at this set size, there won't be at any
                // higher set size
                if (!enoughData) {
                    log.debug("\tnot enough data at set size " + setSize + ", assuming dependence " +
                            "between " + data.getName(targetIdx) + " and " + data.getName(xIdx));
                    type = "keep-default";
                    break;
                }
            }
            // if dependent, add variable back into CPC
            if (!isIndependent) {
                log.debug("\tkeeping " + data.getName(xIdx) + " as member of " + data.getName(targetIdx) + " CPC.");
                log.debug("DECISION: mode=prune type=" + type + " target=" + data.getName(targetIdx) + " x=" + data.getName(xIdx) + " dof=" + data.traditionalDof + " tableSize=" + data.tableSize + " es=" + lastScore[2] + " sizeZ=" + lastScore[3] + " n=" + data.sampleSize);
                currentCPC.add(xIdx);
            }
        }
    }

    public MMPC setThresholdModule(ThresholdModule mod) {
        threshModule = mod;
        return this;
    }
}
