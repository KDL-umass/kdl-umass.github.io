/**
 * $Id: DefaultThreshold.java 262 2008-11-10 19:23:11Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 *
 */

package kdl.bayes.skeleton.util;

public class DefaultThreshold extends ThresholdModule {
    /**
     * There must be "at least 5 instances on average per parameter (count) to be estimated"
     * which I interpret to mean (sample size / dof) > 5.
     *
     * @return true if there is enough data
     */
    public DefaultThreshold(int sampleSize) {
        this(sampleSize, 5);
    }

    public DefaultThreshold(int sampleSize, double numPerCell) {
        dofThreshold = new Double(sampleSize / numPerCell).longValue();
    }

    public boolean enoughData(BayesData data) {
        return tableSizeOK(data) && data.empiricalDof < dofThreshold;
    }
}
