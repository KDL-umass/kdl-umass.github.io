/**
 * $Id: SkeletonFinder.java 286 2009-09-23 19:35:24Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 *
 */

package kdl.bayes.skeleton;

import kdl.bayes.skeleton.util.BayesData;
import kdl.bayes.util.Assert;
import kdl.bayes.util.constraint.Constraint;
import kdl.bayes.util.constraint.Dependence;
import kdl.bayes.util.constraint.dSeparation;
import org.apache.log4j.Logger;
import weka.core.Instances;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.*;

public abstract class SkeletonFinder {

    protected static Logger log = Logger.getLogger(SkeletonFinder.class);

    public double pValThreshold = 0.05;

    protected Instances instances;
    protected BayesData data;

    protected List<List<Integer>> neighbors;
    protected Map<Set<Integer>, Set<Integer>> sepSets; //Sets of variables that d-separate two other variables.
    //For connected variables the sepSet is empty.
    protected Map<Set<Integer>, Integer> edgeStatus;  //Indicator whether edges were added by default or not.
    // {-1,0,1} = {excluded, added by default, included}
    protected Map<Set<Integer>, Double> effectSize; //For edges appearing in the skeleton, the measured estimate of effect size.
    //For edges not appearing in the skeleton, the effect size = 0.0
    protected int numVariables;
    private List<String> varNames;

    protected Set<Constraint> constraints; //Constraints identified during skeleton identification.

    protected int statCalls;
    protected long runtime;

    public SkeletonFinder(Instances instances) {
        this.instances = instances;
        data = new BayesData(instances);
        numVariables = instances.numAttributes();
        varNames = getNames(instances);
        neighbors = new ArrayList<List<Integer>>();

        for (int i = 0; i < numVariables; i++) {
            neighbors.add(new ArrayList<Integer>());
        }

        sepSets = new HashMap<Set<Integer>, Set<Integer>>();
        edgeStatus = new HashMap<Set<Integer>, Integer>();
        effectSize = new HashMap<Set<Integer>, Double>();
        statCalls = 0;

        constraints = new HashSet<Constraint>();
    }

    public SkeletonFinder(SkeletonFinder skeleton) {
        this.instances = skeleton.instances;
        data = skeleton.data;
        numVariables = instances.numAttributes();
        varNames = getNames(instances);

        neighbors = new ArrayList<List<Integer>>();

        for (int i = 0; i < numVariables; i++) {
            neighbors.add(new ArrayList<Integer>(skeleton.neighbors.get(i)));
        }

        sepSets = new HashMap<Set<Integer>, Set<Integer>>();

        Set<Set<Integer>> keySet = skeleton.sepSets.keySet();

        for (Set<Integer> key : keySet) {
            sepSets.put(key, new HashSet<Integer>(skeleton.sepSets.get(key)));
        }

        edgeStatus = new HashMap<Set<Integer>, Integer>(skeleton.edgeStatus);
        effectSize = new HashMap<Set<Integer>, Double>(skeleton.effectSize);

        statCalls = 0;
        constraints = new HashSet<Constraint>(skeleton.constraints);

    }

    public void addConstraint(int xIdx, int yIdx, Set<Integer> zIdxs, boolean positiveConstraint, double weight) {
        dSeparation newConstraint = new dSeparation(xIdx, yIdx, zIdxs, weight);
        //log.info("Adding constraint: " + newConstraint);
        constraints.add(newConstraint);
    }


    /**
     * Adds an undirected edge between x and y
     *
     * @param x
     * @param y
     */
    public void addEdge(int x, int y) {
        List<Integer> xNeigh = neighbors.get(x);
        List<Integer> yNeigh = neighbors.get(y);

        if (!xNeigh.contains(y)) {
            xNeigh.add(y);
        }

        if (!yNeigh.contains(x)) {
            yNeigh.add(x);
        }
    }

    /**
     * Build fully connected neighbor sets. Used as the starting point for some constraint-based methods.
     *
     * @return
     */
    protected List<List<Integer>> buildCompleteGraph() {
        List<List<Integer>> completeGraph = new ArrayList<List<Integer>>();

        //add every variable to every other neighbor set.
        List<Integer> totalList = new ArrayList<Integer>();
        for (int i = 0; i < numVariables; i++) {
            totalList.add(i);
        }

        for (int j = 0; j < numVariables; j++) {
            List<Integer> jList = new ArrayList<Integer>(totalList);
            jList.remove(j);
            completeGraph.add(jList);
        }
        return completeGraph;
    }

    public void clearAllEdges() {
        neighbors = new ArrayList<List<Integer>>();

        for (int i = 0; i < numVariables; i++) {
            neighbors.add(new ArrayList<Integer>());
        }
    }

    /**
     * Compute Neighbors does the work of finding a skeleton from data.
     *
     * @return the number of stat calls required
     */
    public abstract int computeNeighbors();


    /**
     * Check whether one set is a subset of another set.
     *
     * @param set
     * @param subsets
     * @return
     */
    public boolean containsSubset(Set<Integer> set, Set<Set<Integer>> subsets) {
        for (Set<Integer> subset : subsets) {
            if (set.containsAll(subset)) {
                return true;
            }
        }
        return false;
    }


    /**
     * For each variable T, if X is in the Neighbors of T, check that T is in the
     * Neighbors of X.  If it is not, remove X from Neighbors of T.
     * This is the AND of both CPCs.
     */
    protected void enforceAndConsistency() {
        for (int tIdx = 0; tIdx < neighbors.size(); tIdx++) {
            //int tIdx = iterator.next();
            List<Integer> cpcOfT = neighbors.get(tIdx);
            for (Iterator<Integer> cpcIterator = cpcOfT.iterator(); cpcIterator.hasNext();) {
                int xIdx = cpcIterator.next();
                List<Integer> cpcOfX = neighbors.get(xIdx);
                if (!cpcOfX.contains(tIdx)) {
                    log.debug("The neighnbors of " + data.getName(tIdx) + " and " + data.getName(xIdx) + " are not" +
                            " reciprocal, removing " + data.getName(xIdx) + " from neighbors of " + data.getName(tIdx));
                    cpcIterator.remove();
                }
            }
        }
    }


    /**
     * For each variable T, if X is in the Neighbors of T, check that T is in the Neighbors of X.
     * If not, then add T to the neighbors of X.
     * The skeleton contains the OR of both CPCs.
     */
    protected void enforceOrConsistency() {
        for (int tIdx = 0; tIdx < neighbors.size(); tIdx++) {
            //int tIdx = iterator.next();
            List<Integer> cpcOfT = neighbors.get(tIdx);
            for (Iterator<Integer> cpcIterator = cpcOfT.iterator(); cpcIterator.hasNext();) {
                int xIdx = cpcIterator.next();
                List<Integer> cpcOfX = neighbors.get(xIdx);
                if (!cpcOfX.contains(tIdx)) {
                    log.debug("The neighbors of " + data.getName(tIdx) + " and " + data.getName(xIdx) + " are not" +
                            " reciprocal, adding " + data.getName(xIdx) + " to the neighbors of " + data.getName(tIdx));
                    cpcOfX.add(tIdx);
                }
            }
        }
    }


    /**
     * Find colliders returns all the *unshielded* colliders currently in the skeleton.
     * Unshielded means that if X - Y - Z then X is not adjacent to Z
     * NB: Assumes the BN structure is currently empty.
     *
     * @param skeleton
     * @return
     */
    public Set<List<Integer>> findColliders() {
        Set<List<Integer>> triples = findTriples();

        //Now prune triples based on the sepsets.
        //Triple appears in the order : x,y,z where z is the possible collider.
        Set<List<Integer>> colliders = new HashSet<List<Integer>>();
        for (List<Integer> triple : triples) {
            int xIdx = triple.get(0);
            int yIdx = triple.get(1);
            int zIdx = triple.get(2);

            Set<Integer> edge = new HashSet<Integer>();
            edge.add(xIdx);
            edge.add(yIdx);
            Set<Integer> sepset = getSepset(edge);

            try {
                if (!hasEdge(xIdx, yIdx) && !sepset.contains(zIdx)) {
                    colliders.add(triple);
                }
            } catch (NullPointerException ex) {
                log.info(Arrays.deepToString(edge.toArray()));
                log.info(xIdx + "," + yIdx + "," + zIdx);
                ex.printStackTrace();
                System.exit(1);
            }
        }

        return colliders;
    }

    public Set<List<Integer>> findTriples() {
        Set<List<Integer>> triples = new HashSet<List<Integer>>();

        //First get the triples
        for (int i = 0; i < numVariables; i++) {
            List<Integer> neighbors = getNeighbors(i);
            for (Integer neighbor : neighbors) {
                List<Integer> neighbors2d = getNeighbors(neighbor);

                for (Integer neighbor2d : neighbors2d) {
                    if (neighbor2d > i) {  //Should have already added if neighbor2d is less than  i
                        List<Integer> triple = new ArrayList<Integer>();
                        triple.add(i);
                        triple.add(neighbor2d);
                        triple.add(neighbor);
                        triples.add(triple);
                    }
                }

            }
        }
        return triples;
    }


    public Set<Constraint> getConstraints() {
        return constraints;
    }

    public BayesData getData() {
        return data;
    }

    /**
     * Edges are stored as Set<Integer> which is unordered. This method creates
     * the edge from two indices.
     *
     * @param var1
     * @param var2
     * @return
     */
    public Set<Integer> getEdge(int var1, int var2) {
        Set<Integer> edge = new HashSet<Integer>();
        edge.add(var1);
        edge.add(var2);
        return edge;
    }

    public Instances getInstances() {
        return instances;
    }


    public List<String> getNames() {
        return varNames;
    }

    public List<Integer> getNeighbors(int targetIdx) {
        return neighbors.get(targetIdx);
    }

    public int getNumStatisticalCalls() {
        return statCalls;
    }

    public void setStatCalls(int calls) {
        statCalls = calls;
    }

    public long getRuntime() {
        return runtime;
    }

    public void setRuntime(long time) {
        runtime = time;
    }

    public boolean hasEdge(int x, int y) {
        Assert.condition(neighbors.get(x).contains(y) == neighbors.get(y).contains(x), "Edges must be reciprocal");
        return neighbors.get(x).contains(y);
    }

    protected boolean hasSepsetForEdge(Set<Integer> edge) {
        return sepSets.containsKey(edge);
    }

    /**
     * Find all variables on undirected paths between var1 and var2
     *
     * @param var1
     * @param var2
     * @param skeleton
     * @return
     */
    public Set<Integer> getAdjPath(int var1, int var2) {
        Set<Integer> adjPath = new HashSet<Integer>();
        //Starting at var1, construct all paths between var1 and var2.
        List<Integer> startPath = new ArrayList<Integer>();
        startPath.add(var1);
        Set<List<Integer>> currentPaths = new HashSet<List<Integer>>();
        currentPaths.add(startPath);

        //Expanded list maintains the list of explored nodes. To find the set of nodes
        // it is sufficient to expand every node on a path exactly once.
        // COntingent List makes sure that paths that hit an expanded node are also added to the adjPath.
        Set<Integer> expandedList = new HashSet<Integer>();
        Set<Integer> contingentList = new HashSet<Integer>();
        Map<Integer, Set<List<Integer>>> contingentMap = new HashMap<Integer, Set<List<Integer>>>();

        while (!currentPaths.isEmpty()) {
            Set<List<Integer>> newPaths = new HashSet<List<Integer>>();
            for (List<Integer> path : currentPaths) {
                //Get last variable on path
                int lastVar = path.get(path.size() - 1);

                //If the last var has been expanded and is on a path
                if (contingentList.contains(lastVar)) {
                    adjPath.addAll(path);
                    continue;
                }

                //if the last var has been expanded but isn't on a path yet.
                if (expandedList.contains(lastVar)) {
                    Set<List<Integer>> pathSet = new HashSet<List<Integer>>();
                    if (contingentMap.containsKey(lastVar)) {
                        pathSet = contingentMap.get(lastVar);

                    }
                    pathSet.add(path);
                    contingentMap.put(lastVar, pathSet);
                    continue;
                }

                expandedList.add(lastVar);
                List<Integer> neighbors = getNeighbors(lastVar);

                log.debug("Path:" + path);

                for (Integer neighbor : neighbors) {

                    if (adjPath.contains(neighbor)) {
                        contingentList.add(lastVar);
                    }


                    if (!path.contains(neighbor)) {
                        if (neighbor == var2 || adjPath.contains(neighbor)) {
                            //Found the target or found a path that leads to a target.
                            adjPath.addAll(path);
                            continue;
                        }

                        // Make sure path doesn't contain a loop, and keep looking
                        List<Integer> newPath = new ArrayList<Integer>(path);
                        newPath.add(neighbor);
                        newPaths.add(newPath);
                    }
                }

            }
            currentPaths = newPaths;
            log.debug("Adjacency Path: " + adjPath);

            if (adjPath.size() == numVariables - 1) {  //AdjPath contains the start path
                break; //Already found all variables.
            }

        }

        Set<Integer> addList = new HashSet<Integer>();

        for (Integer pathVar : adjPath) {
            if (contingentMap.containsKey(pathVar)) {
                Set<List<Integer>> contingentPaths = contingentMap.get(pathVar);
                for (List<Integer> path : contingentPaths) {
                    addList.addAll(path);
                }
            }
        }
        adjPath.addAll(addList);
        adjPath.remove(new Integer(var1));  //Do it once, for slight optimization
        return adjPath;
    }

    public int getNumVariables() {
        return numVariables;
    }

    public Set<Integer> getSepset(Set<Integer> pair) {
        return sepSets.get(pair);
    }

    public boolean[][] getSkeleton() {
        boolean[][] skeleton = new boolean[numVariables][numVariables];
        //for (Integer u : neighbors.keySet()) {
        for (int u = 0; u < neighbors.size(); u++) {
            for (Integer v : neighbors.get(u)) {
                skeleton[u][v] = true;
                Assert.condition(neighbors.get(v).contains(u), "Neighbor sets are not reciprocal");
                skeleton[v][u] = true;
            }
        }
        return skeleton;
    }

    public void removeEdge(int x, int y) {
        neighbors.get(x).remove(new Integer(y));
        neighbors.get(y).remove(new Integer(x));
    }

    public void save(String filename) {
        try {
            PrintWriter printWriter = new PrintWriter(new FileWriter(filename));
            save(printWriter);
            printWriter.close();
        } catch (Exception e) {
            log.warn("Unable to open file for writing.");
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void save(PrintWriter outfile) {

        String line = "R\t" + runtime;
        outfile.println(line);

        line = "S\t" + statCalls;
        outfile.println(line);


        for (int i = 0; i < numVariables; i++) {
            for (int j = i + 1; j < numVariables; j++) {

                String var1 = varNames.get(i);
                String var2 = varNames.get(j);

                boolean edgeDecision = hasEdge(i, j);

                String sepsetStr = "";
                double power = 0.0;

                if (!edgeDecision) {
                    Set<Integer> pair = new HashSet<Integer>();
                    pair.add(i);
                    pair.add(j);

                    //log.info(i + ", " + j);

                    Set<Integer> sepset = getSepset(pair);

                    sepsetStr = setToString(sepset);
                    //log.info(sepsetStr);

                    for (Constraint constraint : constraints) {
                        if (constraint instanceof dSeparation) {
                            dSeparation d = (dSeparation) constraint;
                            int dX = d.getX();
                            int dY = d.getY();

                            if ((dX == i && dY == j) || (dY == i && dX == j)) {
                                power = constraint.getWeight();
                            }
                        }
                    }

                }


                line = "V\t" + var1 + "\t" + var2 + "\t" + edgeDecision + (edgeDecision ? "" : "\t" + power + "\t" + sepsetStr);
                outfile.println(line);
            }
        }

    }

    public String setToString(Set outSet) {
        StringBuffer sb = new StringBuffer("[");
        int i = 1;
        for (Object o : outSet) {
            sb.append(o.toString());
            if (i < outSet.size()) {
                sb.append(",");
            }
            i++;
        }
        sb.append("]");
        return sb.toString();
    }

    public void read(String filename) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filename));
            read(reader);
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }


    }

    public void read(BufferedReader reader) {
        try {
            String str;
            while ((str = reader.readLine()) != null) {

                if (str.startsWith("R")) {
                    String[] fields = str.split("\t");
                    runtime = Long.parseLong(fields[1]);
                }

                if (str.startsWith("S")) {
                    String[] fields = str.split("\t");
                    statCalls = Integer.parseInt(fields[1]);
                }

                if (str.startsWith("V")) {
                    String[] fields = str.split("\t");
                    String var1Name = fields[1];

                    int var1 = varNames.indexOf(var1Name);
                    String var2Name = fields[2];
                    int var2 = varNames.indexOf(var2Name);

                    boolean edgeDecision = Boolean.parseBoolean(fields[3]);

                    if (edgeDecision) {
                        addEdge(var1, var2);
                        constraints.add(new Dependence(var1, var2, numVariables, 1.0));
                    } else {
                        double power = Double.parseDouble(fields[4]);
                        String sepsetStr = fields[5];
                        Set<Integer> sepset = getSepsetFromString(sepsetStr);

                        setSepset(var1, var2, sepset);
                        addConstraint(var1, var2, sepset, true, power);
                    }
                }

            }
        } catch (Exception e) {

        }


    }

    public void setEdgeStatus(int var1, int var2, int status) {
        edgeStatus.put(getEdge(var1, var2), status);
    }

    public void setEffectSize(int var1, int var2, double w) {
        effectSize.put(getEdge(var1, var2), w);
    }

    public void setPValueThreshold(double newPval) {
        pValThreshold = newPval;
    }

    public void setSepset(int xIdx, int yIdx, Set<Integer> zIdxs) {
        Set<Integer> edge = getEdge(xIdx, yIdx);
        Assert.condition(!sepSets.containsKey(edge), "Sepsets already contain this pair.");
        if (zIdxs == null) {
            zIdxs = new HashSet<Integer>();
        }
        sepSets.put(edge, zIdxs);
    }


    private List<String> getNames(Instances instances) {
        List<String> names = new ArrayList<String>();

        for (int i = 0; i < instances.numAttributes(); i++) {
            names.add(instances.attribute(i).name());
        }
        return names;
    }


    public Set<Integer> getSepsetFromString(String sepsetStr) {

        if (sepsetStr.length() == 2) {
            return new HashSet<Integer>();
        }

        String[] values = sepsetStr.substring(1, sepsetStr.length() - 1).split(",");
        Set<Integer> sepset = new HashSet<Integer>();
        for (String value : values) {
            sepset.add(Integer.parseInt(value));
        }
        return sepset;
    }

    protected List<List<Integer>> buildPairs(boolean isOrdered) {
        List<List<Integer>> pairsList = new ArrayList<List<Integer>>();
        for (int var1 = 0; var1 < numVariables; var1++) {
            for (int var2 = 0; var2 < numVariables; var2++) {
                if (var1 != var2) {
                    if (!isOrdered || var1 < var2) {
                        List<Integer> pair = new ArrayList<Integer>();
                        pair.add(var1);
                        pair.add(var2);
                        pairsList.add(pair);
                    }
                }
            }
        }
        return pairsList;
    }
}
