/**
 * $Id: PowerBayesNet.java 267 2009-02-18 20:12:07Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 */

package kdl.bayes;

import kdl.bayes.util.Assert;
import kdl.bayes.util.ProbDistribution;
import kdl.bayes.util.StatUtil;
import org.apache.log4j.Logger;
import weka.classifiers.bayes.BayesNet;
import weka.classifiers.bayes.net.BIFReader;
import weka.classifiers.bayes.net.ParentSet;
import weka.classifiers.bayes.net.estimate.DiscreteEstimatorBayes;
import weka.core.Instance;
import weka.core.Instances;
import weka.estimators.Estimator;

import java.util.*;

/**
 * BayesNet
 * Author: mhay
 */
public class PowerBayesNet extends BayesNet implements ProbDistribution {
    protected static Logger log = Logger.getLogger(PowerBayesNet.class);
    private double equivSampleSize = 10;
    private boolean[] staleCPTs;
    boolean anyStaleCPTs = true;

    public PowerBayesNet() {
        super();
        // set prior to 0 so estimator holds raw counts
        getEstimator().setAlpha(0);
    }

    /**
     * Initializes Bayes net using the structure and CPTs from
     * a Bayes net stored in an XML BIF file.
     *
     * @param xmlFilename
     */
    public PowerBayesNet(String xmlFilename) {
        this();
        try {
            BayesNet bn = new BIFReader().processFile(xmlFilename);
            m_ParentSets = bn.getParentSets();
            m_Distributions = bn.m_Distributions;
            m_Instances = bn.m_Instances;
            m_Instances.setClassIndex(0);
            m_NumClasses = m_Instances.numClasses();
            initStaleCPTs(false);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("error: " + e);
            System.exit(-1);
        }
    }

    private void initStaleCPTs(boolean isStale) {
        staleCPTs = new boolean[this.getNrOfNodes()];
        for (int i = 0; i < staleCPTs.length; i++) {
            staleCPTs[i] = isStale;
        }
        anyStaleCPTs = isStale;
    }

    public PowerBayesNet(Instances instances) {
        this();
        m_Instances = instances;
        m_Instances.setClassIndex(0);
        m_NumClasses = instances.numClasses();
        initStructure();
        initStaleCPTs(true);
        estimateCPTs();
    }

    public PowerBayesNet(Instances instances, boolean[][] dag) {
        this();
        Assert.condition(instances.numAttributes() == dag.length,
                "DAG must be same size as number of attributes in instances");
        m_Instances = instances;
        m_Instances.setClassIndex(0);
        m_NumClasses = instances.numClasses();
        initStructure();
        initStaleCPTs(true);

        for (int i = 0; i < dag.length; i++) {
            for (int j = 0; j < dag[i].length; j++) {
                if (dag[i][j]) {
                    getParentSet(j).addParent(i, m_Instances);
                }
            }
        }
    }

    public void addEdge(int fromIdx, int toIdx) {
        anyStaleCPTs = true;
        staleCPTs[toIdx] = true;
        getParentSet(toIdx).addParent(fromIdx, m_Instances);
    }

//    private static double computeProbability(double laplace, DiscreteEstimatorBayes estimator,
//                                             Instance instance,
//                                             int iAttribute
//    ) {
//        int iAttrCardinality = instance.attribute(iAttribute).numValues();
//        double count = laplace + estimator.getCount(instance.value(iAttribute));
//        double total = laplace * iAttrCardinality;
//
//        for (int iAttrValue = 0; iAttrValue < iAttrCardinality; iAttrValue++) {
//            total += estimator.getCount(iAttrValue);
//        }
//        return count / total;
//    }

    public void estimateCPT(int varIdx) {
        // initialize the estimators for this variable
        ParentSet parentSet = getParentSet(varIdx);
        int varCardinality = m_Instances.attribute(varIdx).numValues();
        int numParentConfigs = parentSet.getCardinalityOfParents();

        Estimator[] estimators = new Estimator[numParentConfigs];

        for (int iParent = 0; iParent < parentSet.getCardinalityOfParents(); iParent++) {
            estimators[iParent] =
                    new DiscreteEstimatorBayes(varCardinality, 0);
        }

        // scan instances and update counts
        Enumeration enumInsts = m_Instances.enumerateInstances();
        while (enumInsts.hasMoreElements()) {
            Instance instance = (Instance) enumInsts.nextElement();
            double iCPT = 0;
            for (int i = 0; i < parentSet.getNrOfParents(); i++) {
                int parentIdx = parentSet.getParent(i);
                iCPT = iCPT * m_Instances.attribute(parentIdx).numValues() +
                        instance.value(parentIdx);
            }

            estimators[(int) iCPT].addValue(instance.value(varIdx),
                    instance.weight());

        }

        // store in m_Distributions
        m_Distributions[varIdx] = estimators;
        staleCPTs[varIdx] = false;
    }

    public void estimateCPTs() {
        try {
            super.estimateCPTs();
        } catch (Exception e) {
            System.err.println(e);
            e.printStackTrace();
            System.exit(-1);
        }
        for (int i = 0; i < staleCPTs.length; i++) {
            staleCPTs[i] = false;
        }
        anyStaleCPTs = false;
    }

    public void estimateCPTs(Instances instances) {
        instances.setClassIndex(0);
        Assert.condition(m_Instances.equalHeaders(instances),
                "Instances do not match structure of this Bayes net");
        m_Instances = instances;
        estimateCPTs();
    }

    /**
     * copied from Weka, but fixed two bugs:
     * 1. assumes variables are ordered so that parents are sampled prior to children
     * 2. had minor bugs in sampling from inverse CDF:
     * (fRandom > currProb)
     * should be
     * (fRandom >= currProb || currProb == 0.0)
     */
    public void generateInstances(int m_nNrOfInstances, int randomSeed) {
        if (anyStaleCPTs) {
            estimateCPTs();
        }
        Random random = new Random(randomSeed);

        int nNrOfAtts = m_Instances.numAttributes();
        int[] sortedIndexes = topologicalSort();
        boolean[] valueSampled = new boolean[nNrOfAtts];
        for (int i = 0; i < valueSampled.length; i++) {
            valueSampled[i] = false;
        }

        setEquivalentSampleSize(0);
        for (int iInstance = 0; iInstance < m_nNrOfInstances; iInstance++) {
            Instance instance = new Instance(nNrOfAtts);
            instance.setDataset(m_Instances);

            for (int i = 0; i < nNrOfAtts; i++) {
                int iAttribute = sortedIndexes[i];
                double iCPT = 0;

                for (int iParent = 0; iParent < m_ParentSets[iAttribute].getNrOfParents(); iParent++) {
                    int nParent = m_ParentSets[iAttribute].getParent(iParent);
                    Assert.condition(valueSampled[nParent],
                            "Must sample parent before you can sample the child!!");
                    iCPT = iCPT * m_Instances.attribute(nParent).numValues() + instance.value(nParent);
                }

                double fRandom = random.nextInt(1000) / 1000.0f;
                int iValue = 0;
                Assert.condition(fRandom < 1, "random number is 1!");
                double currProb = m_Distributions[iAttribute][(int) iCPT].getProbability(iValue);
                while (fRandom > currProb ||
                        StatUtil.equalDoubles(fRandom, currProb) ||
                        StatUtil.equalDoubles(currProb, 0.0)) {
                    fRandom = fRandom - currProb;
                    iValue++;
                    currProb = m_Distributions[iAttribute][(int) iCPT].getProbability(iValue);
                }
                instance.setValue(iAttribute, iValue);
                valueSampled[iAttribute] = true;
            }
            m_Instances.add(instance);
            double logProb = logProbability(instance);
            Assert.condition(logProb <= 0 && logProb > Double.NEGATIVE_INFINITY, "Invalid instance has been generated");
        }
    } // GenerateInstances

    public boolean[][] getDag() {
        boolean[][] dag = new boolean[getNrOfNodes()][getNrOfNodes()];
        for (int iNode = 0; iNode < getNrOfNodes(); iNode++) {
            for (int iParent = 0; iParent < getParentSet(iNode).getNrOfParents(); iParent++) {
                int nParent = getParentSet(iNode).getParent(iParent);
                dag[nParent][iNode] = true;
            }
        }
        return dag;
    }

    public double getEquivSampleSize() {
        return equivSampleSize;
    }

    public boolean[][] getNeighborsAdjList() {
        int numNodes = this.getNrOfNodes();
        boolean[][] neighborList = new boolean[numNodes][numNodes];

        //Should be initialized to false upon creation, but just in case
        for (int i = 0; i < neighborList.length; i++) {
            for (int j = 0; j < neighborList[0].length; j++) {
                neighborList[i][j] = false;
            }
        }

        for (int iNode = 0; iNode < this.getNrOfNodes(); iNode++) {
            for (int iParent = 0; iParent < getParentSet(iNode).getNrOfParents(); iParent++) {
                int nParent = getParentSet(iNode).getParent(iParent);
                neighborList[iNode][nParent] = true;
                neighborList[nParent][iNode] = true;
            }
        }
        return neighborList;
    }

    public double getVariableLogBDeuScore(int iAttribute) {
        if (staleCPTs[iAttribute]) {
            estimateCPT(iAttribute);
        }
        double fLogScore = 0.0;
        int q_i = getParentSet(iAttribute).getCardinalityOfParents();
        for (int iParent = 0; iParent < q_i; iParent++) {
            DiscreteEstimatorBayes est = (DiscreteEstimatorBayes) m_Distributions[iAttribute][iParent];
            int r_i = m_Instances.attribute(iAttribute).numValues();
            Assert.condition(r_i ==
                    est.getNumSymbols(), "Expected attribute cardinality to equal estimator cardinality");

            double n_ijk_prime = equivSampleSize / (r_i * q_i);
            double n_ij_prime = n_ijk_prime * r_i;
            double n_ij = 0;

            for (int iAttrValue = 0; iAttrValue < est.getNumSymbols(); iAttrValue++) {
                double n_ijk = est.getCount(iAttrValue);
                n_ij += n_ijk;
                fLogScore += StatUtil.gammaLn(n_ijk + n_ijk_prime);
                fLogScore -= StatUtil.gammaLn(n_ijk_prime);
            }
            fLogScore += StatUtil.gammaLn(n_ij_prime);
            fLogScore -= StatUtil.gammaLn(n_ij_prime + n_ij);
        }
        return fLogScore;
    }

    public void initStructure() {
        try {
            super.initStructure();
            getEstimator().initCPTs(this);
        } catch (Exception e) {
            System.err.println(e);
            e.printStackTrace();
            System.exit(-1);
        }
    }

    public double logBDeuScore() {
        if (anyStaleCPTs) {
            estimateCPTs();
        }
        double fLogScore = 0.0;
        // i - attribute index
        // j - parent configuration index
        // k - attribute value index
        // r_i - cardinality of attribute i
        // q_i - cardinality of parent configurations for attribute i

        for (int iAttribute = 0; iAttribute < m_Instances.numAttributes(); iAttribute++) {
            fLogScore += getVariableLogBDeuScore(iAttribute);
        }
        return fLogScore;
    }

    /**
     * Log-likelihood of training data is
     * \prod^n_{i=1} \prod^{q_i}_{j=1} \prod^{r_i}_{k=1}[N_{ijk}/N_{ij}]^{N_ijk}
     *
     * @return loglikelihood
     */

//    public double logLikelihood() {
//        double fLogScore = 0.0;
//        // i - attribute index
//        // j - parent configuration index
//        // k - attribute value index
//        // r_i - cardinality of attribute i
//        // q_i - cardinality of parent configurations for attribute i
//
//        for (int iAttribute = 0; iAttribute < m_Instances.numAttributes(); iAttribute++) {
//            int q_i = getParentSet(iAttribute).getCardinalityOfParents();
//            for (int iParent = 0; iParent < q_i; iParent++) {
//                DiscreteEstimatorBayes est = (DiscreteEstimatorBayes) m_Distributions[iAttribute][iParent];
//                int r_i = m_Instances.attribute(iAttribute).numValues();
//                Assert.condition(r_i ==
//                        est.getNumSymbols(), "Expected attribute cardinality to equal estimator cardinality");
//
//                for (int iAttrValue = 0; iAttrValue < est.getNumSymbols(); iAttrValue++) {
//                    double count = est.getCount(iAttrValue);
//                    double probability = est.getProbability(iAttrValue);
//                    fLogScore += count > 0 ? (Math.log(probability) * count) : 0;
//                }
//            }
//        }
//        return fLogScore;
//    }
    public double logProbability(Instances instances) {
        if (anyStaleCPTs) {
            estimateCPTs();
        }
        double ll = 0;
        Enumeration enumInsts = instances.enumerateInstances();
        while (enumInsts.hasMoreElements()) {
            Instance instance = (Instance) enumInsts.nextElement();
            ll += logProbability(instance);
        }
        return ll;
    }

    public double logProbability(Instance instance) {
        if (anyStaleCPTs) {
            estimateCPTs();
        }
        double logProb = 0;
        for (int iAttribute = 0; iAttribute < instance.numAttributes(); iAttribute++) {
            int r_i = instance.attribute(iAttribute).numValues();
            int q_i = getParentSet(iAttribute).getCardinalityOfParents();
            double iCPT = 0;
            for (int iParent = 0; iParent < getParentSet(iAttribute).getNrOfParents(); iParent++) {
                int nParent = getParentSet(iAttribute).getParent(iParent);
                iCPT = iCPT * instance.attribute(nParent).numValues() + instance.value(nParent);
            }

            DiscreteEstimatorBayes estimator = (DiscreteEstimatorBayes) m_Distributions[iAttribute][(int) iCPT];
            double n_ijk_prime = equivSampleSize / (r_i * q_i);
            double n_ij_prime = n_ijk_prime * r_i;
            double n_ijk = estimator.getCount(instance.value(iAttribute));

            double n_ij = 0;
            for (int iAttrValue = 0; iAttrValue < r_i; iAttrValue++) {
                n_ij += estimator.getCount(iAttrValue);
            }
            double probability = (n_ijk + n_ijk_prime) / (n_ij + n_ij_prime);

            logProb += Math.log(probability);
        }
        return logProb;
    }

//    private double logSmoothedProbability(Instance instance) {
//        double logProb = 0;
//        for (int iAttribute = 0; iAttribute < instance.numAttributes(); iAttribute++) {
//            double iCPT = 0;
//            for (int iParent = 0; iParent < getParentSet(iAttribute).getNrOfParents(); iParent++) {
//                int nParent = getParentSet(iAttribute).getParent(iParent);
//                iCPT = iCPT * m_Instances.attribute(nParent).numValues() + instance.value(nParent);
//            }
//
//            DiscreteEstimatorBayes estimator = (DiscreteEstimatorBayes) m_Distributions[iAttribute][(int) iCPT];
//            double probability = computeProbability(laplace, estimator, instance, iAttribute);
//            if (probability <= 0 || probability > 1) {
//                System.out.print("P( ");
//                System.out.print(instance.attribute(iAttribute).name());
//                System.out.print("=");
//                System.out.print(instance.stringValue(iAttribute));
//                System.out.print(" | ");
//                for (int iParent = 0; iParent < getParentSet(iAttribute).getNrOfParents(); iParent++) {
//                    int nParent = getParentSet(iAttribute).getParent(iParent);
//                    System.out.print(instance.attribute(nParent).name());
//                    System.out.print("=");
//                    System.out.print(instance.stringValue(nParent));
//                    System.out.print(",");
//                }
//                System.out.println(" )=" + probability);
//                Assert.condition(false, "Instance has invalid probability: " + probability);
//            }
//            logProb += Math.log(probability);
//        }
//        return logProb;
//    }

    public void removeEdge(int fromIdx, int toIdx) {
        anyStaleCPTs = true;
        staleCPTs[toIdx] = true;
        getParentSet(toIdx).deleteParent(fromIdx, m_Instances);
    }

    public void setEquivalentSampleSize(double ess) {
        equivSampleSize = ess;
    }

    /**
     * Not efficient but it works
     *
     * @return partially ordered list of node indexes (if i is lower in order than j, then i is ancestor (or cousin/sibling) of j
     */
    public int[] topologicalSort() {
        int numNodes = getNrOfNodes();
        int[] orderedIndexes = new int[numNodes];
        int[] inDegree = new int[numNodes];

        // initialize inDegree array
        for (int i = 0; i < numNodes; i++) {
            inDegree[i] = m_ParentSets[i].getNrOfParents();
        }

        int currRank = 0;
        while (currRank < numNodes) {
            int idxOfLeastRankedNode = -1;

            // find the next least rank node
            for (int i = 0; i < numNodes; i++) {
                if (inDegree[i] == 0) {
                    // we found the next node
                    idxOfLeastRankedNode = i;

                    // decrement inDegree of all children of i
                    for (int j = 0; j < numNodes; j++) {
                        if (m_ParentSets[j].contains(idxOfLeastRankedNode)) {
                            inDegree[j]--;
                        }
                    }
                    break;
                }
            }
            Assert.condition(idxOfLeastRankedNode >= 0, "Did not find a node!  Perhaps graph is not acyclic?");
            orderedIndexes[currRank] = idxOfLeastRankedNode;
            inDegree[idxOfLeastRankedNode] = -1;  // so it's not added again
            currRank++;
        }

        // check order
        for (int i = orderedIndexes.length - 1; i >= 0; i--) {
            int attrIdx = orderedIndexes[i];
            ParentSet parents = getParentSet(attrIdx);
            // ensure each parent is lower in the order than attrIdx
            for (int parentSetIdx = 0; parentSetIdx < parents.getNrOfParents(); parentSetIdx++) {
                int parentIdx = parents.getParent(parentSetIdx);
                // find parent in ordered indexes
                for (int j = 0; j < orderedIndexes.length; j++) {
                    if (parentIdx == orderedIndexes[j]) {
                        Assert.condition(j < i, "Parent higher than child!");
                    }
                }
            }
        }
        return orderedIndexes;
    }

    /**
     * See:
     * D. M. Chickering.  1995.  A transformational characterization of equivalent
     * Bayesian network structures.  UAI.
     *
     * @return partially directed acyclic graph
     */
    public boolean[][] getPDag() {

        List<Edge> orderedEdges = orderEdges();

        findCompelled(orderedEdges);

        return convertToMatrix(orderedEdges);
    }

    /**
     * Changes status of edges from UNKNOWN to COMPELLED or REVERSIBLE
     * <p/>
     * See:
     * D. M. Chickering.  1995.  A transformational characterization of equivalent
     * Bayesian network structures.  UAI.
     */
    private void findCompelled(List<Edge> orderedEdges) {
        for (int edgeIdx = 0; edgeIdx < orderedEdges.size(); edgeIdx++) {
            Edge edge = orderedEdges.get(edgeIdx);
            if (edge.status != Edge.UNKOWN) {
                continue;   // some edges may set by earlier iterations
            }
            int x = edge.parent;
            int y = edge.child;

            // handle the w->x edges
            // For every edge w -> x labelled COMPELLED:
            //    If w is not a parent of y,
            //       then label x -> y and every edge incident into
            //       y with COMPELLED and find next edge labelled UNKNOWN
            //    Else w is a parent and so label w -> y with COMPELLED

            boolean foundW = false;
            for (int edgeIdx2 = 0; edgeIdx2 < orderedEdges.size(); edgeIdx2++) {
                Edge otherEdge = orderedEdges.get(edgeIdx2);
                if (otherEdge.child == x && otherEdge.status == Edge.COMPELLED) {
                    int w = otherEdge.parent;
                    // if w is parent of y, then find w->y and label
                    if (getParentSet(y).contains(w)) {
                        for (int edgeIdx3 = 0; edgeIdx3 < orderedEdges.size(); edgeIdx3++) {
                            Edge wIntoYEdge = orderedEdges.get(edgeIdx3);
                            if (wIntoYEdge.parent == w && wIntoYEdge.child == y) {
                                wIntoYEdge.status = Edge.COMPELLED;
                                break;
                            }
                        }
                    } else {
                        foundW = true;
                        for (int edgeIdx3 = 0; edgeIdx3 < orderedEdges.size(); edgeIdx3++) {
                            Edge intoYEdge = orderedEdges.get(edgeIdx3);
                            if (intoYEdge.child == y) {
                                intoYEdge.status = Edge.COMPELLED;
                            }
                        }
                        break;
                    }
                }
                if (foundW) {
                    break;
                }
            }

            if (foundW) {
                continue;
            }

            // If there exists an edge z -> y such that z != x and z
            // is not a parent of x,
            //   then label x -> y and all UNKNOWN edges incident into y
            //   with COMPELLED.
            // Else
            //   label x -> y and all UKNOWN edges incident into y
            //   with REVERSIBLE
            boolean foundVee = false;
            for (int edgeIdx2 = 0; edgeIdx2 < orderedEdges.size(); edgeIdx2++) {
                Edge otherEdge = orderedEdges.get(edgeIdx2);
                if (otherEdge.child == y && otherEdge.parent != x) {
                    int z = otherEdge.parent;
                    // if z is not a parent of x
                    if (!getParentSet(x).contains(z)) {
                        foundVee = true;
                        break;
                    }
                }
            }

            int label = Edge.REVERSIBLE;
            if (foundVee) {
                label = Edge.COMPELLED;
            }

            for (int edgeIdx2 = 0; edgeIdx2 < orderedEdges.size(); edgeIdx2++) {
                Edge otherEdge = orderedEdges.get(edgeIdx2);
                if (otherEdge.child == y && otherEdge.status == Edge.UNKOWN) {
                    otherEdge.status = label;
                }
            }
        }
    }

    private boolean[][] convertToMatrix(List<Edge> edges) {
        boolean[][] adjacencyMatrix = new boolean[getNrOfNodes()][getNrOfNodes()];
        for (Iterator<Edge> iterator = edges.iterator(); iterator.hasNext();) {
            Edge edge = iterator.next();
            if (edge.status == Edge.COMPELLED) {
                adjacencyMatrix[edge.parent][edge.child] = true;
            } else {
                Assert.condition(edge.status == Edge.REVERSIBLE, "All edges should be either compelled or reversible!");
                adjacencyMatrix[edge.parent][edge.child] = true;
                adjacencyMatrix[edge.child][edge.parent] = true;
            }
        }
        return adjacencyMatrix;
    }

    /**
     * See:
     * D. M. Chickering.  1995.  A transformational characterization of equivalent
     * Bayesian network structures.  UAI.
     *
     * @return ordered list of edges
     */
    private List<Edge> orderEdges() {

        // initialize parent sets
        int numberEdges = 0;
        Map<Integer, Set<Integer>> varToParents = new HashMap<Integer, Set<Integer>>();
        for (int varIdx = 0; varIdx < getNrOfNodes(); varIdx++) {
            Set<Integer> parents = varToParents.get(varIdx);
            if (parents == null) {
                parents = new HashSet<Integer>();
            }
            for (int parentSetIdx = 0; parentSetIdx < getParentSet(varIdx).getNrOfParents(); parentSetIdx++) {
                int parentIdx = getParentSet(varIdx).getParent(parentSetIdx);
                parents.add(parentIdx);
                numberEdges++;
            }
            varToParents.put(varIdx, parents);
        }

        // order the variables topologically
        int[] varIdxs = topologicalSort();
        List<Integer> sortedVarIdxs = new ArrayList<Integer>();
        for (int i = 0; i < varIdxs.length; i++) {
            sortedVarIdxs.add(i, varIdxs[i]);
        }

        // find the next lowest edge:
        // find the lowest ordered variable Y that has an unordered edge
        // to a parent
        // next edge is the one to the highest ordered parent of Y
        List<Edge> orderedEdges = new ArrayList<Edge>();
        int minIdx = 0;
        while (numberEdges > 0) {

            int minVar = -1;

            // find lowest ordered variable with parents
            for (int orderIdx = minIdx; orderIdx < sortedVarIdxs.size(); orderIdx++) {
                int varIdx = sortedVarIdxs.get(orderIdx);
                if (varToParents.get(varIdx).size() > 0) {
                    minIdx = orderIdx;
                    minVar = varIdx;
                    break;
                }
            }

            // find highest order parent of lowest ordered variable
            Set<Integer> parents = varToParents.get(minVar);
            Assert.condition(parents.size() > 0,
                    "Empty parent set for lowest ordered variable");
            int highestOrderParent = -1;
            int highestOrder = -1;
            for (Iterator<Integer> parentsIter = parents.iterator(); parentsIter.hasNext();) {
                int parentIdx = parentsIter.next();
                Assert.condition(sortedVarIdxs.contains(parentIdx),
                        parentIdx + " not in sorted list");
                int order = sortedVarIdxs.indexOf(parentIdx);
                if (order > highestOrder) {
                    highestOrderParent = parentIdx;
                    highestOrder = order;
                }
            }

            // remove parent from parent set
            parents.remove(highestOrderParent);
            orderedEdges.add(new Edge(highestOrderParent, minVar));
            numberEdges--;
        }

        return orderedEdges;
    }

    public boolean[][] getAncestorMatrix() {
        boolean[][] adjMatrix = new boolean[getNrOfNodes()][getNrOfNodes()];
        int[] varIdxs = topologicalSort();
        for (int i = 0; i < varIdxs.length; i++) {
            int varIdx = varIdxs[i];
            // for each parent X, add X->Y to adj matrix, and
            // for each A->X in adj matrix, add A->Y to adj matrix
            for (int parentSetIdx = 0; parentSetIdx < getParentSet(varIdx).getNrOfParents(); parentSetIdx++) {
                int parentIdx = getParentSet(varIdx).getParent(parentSetIdx);
                adjMatrix[parentIdx][varIdx] = true;

                for (int rowIdx = 0; rowIdx < adjMatrix.length; rowIdx++) {
                    if (adjMatrix[rowIdx][parentIdx]) {
                        adjMatrix[rowIdx][varIdx] = true;
                    }
                }
            }
        }
        return adjMatrix;
    }

    public boolean[][] getParentsAndGrandParents() {
        boolean[][] adjMatrix = new boolean[getNrOfNodes()][getNrOfNodes()];
        int[] varIdxs = topologicalSort();
        for (int i = 0; i < varIdxs.length; i++) {
            int varIdx = varIdxs[i];
            // for each parent X, add X->Y to adj matrix, and
            // for each W->X in parentset of X, add W->Y to adj matrix
            for (int parentSetIdx = 0; parentSetIdx < getParentSet(varIdx).getNrOfParents(); parentSetIdx++) {
                int parentIdx = getParentSet(varIdx).getParent(parentSetIdx);
                adjMatrix[parentIdx][varIdx] = true;

                // get parents of my parent
                for (int gParentSetIdx = 0; gParentSetIdx < getParentSet(parentIdx).getNrOfParents(); gParentSetIdx++) {
                    int gParentIdx = getParentSet(parentIdx).getParent(gParentSetIdx);
                    adjMatrix[gParentIdx][varIdx] = true;
                }
            }
        }
        return adjMatrix;
    }

    class Edge {
        public static final int UNKOWN = 0;
        public static final int REVERSIBLE = 1;
        public static final int COMPELLED = 2;
        public int parent;
        public int child;
        public int status;

        public Edge(int x, int y) {
            this.parent = x;
            this.child = y;
            status = UNKOWN;
        }
    }

}
