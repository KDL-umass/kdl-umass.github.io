/**
 * $Id: SearchState.java 260 2008-09-08 14:06:12Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 */

package kdl.bayes.search;

/**
 * SearchState
 */
public abstract class SearchState implements Comparable {

    /**
     * Called when this search algorithm decides to move from
     * the current SearchState to this SearchState.  Allows it
     * to update data structures as necessary.
     */
    public abstract void makeCurrentState();

    public abstract boolean isSame(SearchState other);

    public abstract boolean equals(Object obj);

    public abstract String getScoreStr();
}
