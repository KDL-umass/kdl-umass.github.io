/**
 * $Id: BNSearchStateWithHistory.java 273 2009-03-06 16:41:19Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 */

package kdl.bayes.search;

import kdl.bayes.PowerBayesNet;


public class BNSearchStateWithHistory extends BNSearchState {


    private boolean[][] history;

    public BNSearchStateWithHistory(PowerBayesNet bayesNet) {
        super(bayesNet);
        setHistory();
    }

    public BNSearchStateWithHistory(BNSearchStateWithHistory predecessor, int fromIdx, int toIdx, int op, boolean[][] pastHistory) {
        super(predecessor, fromIdx, toIdx, op);
        setHistory(pastHistory);
        //Check for op == ADD, if so then update history accordingly.
        if (op == ADD) {
            updateHistory(fromIdx, toIdx);
        }
    }

    public boolean[][] getHistory() {
        return history;
    }

    public void setHistory() {
        int size = this.getBayesNet().getNrOfNodes();
        history = new boolean[size][size];
    }

    public void setHistory(boolean[][] pastHistory) {
        int size = pastHistory.length;
        history = new boolean[size][size];

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                history[i][j] = pastHistory[i][j];
            }
        }
    }

    /**
     * Method to maintain the skeleton of every edge added at any point to the network.
     * This differs from the learned network because edges are not removed from the history when deleted
     * during search.
     *
     * @param fromIdx
     * @param toIdx
     */
    public void updateHistory(int fromIdx, int toIdx) {
        history[fromIdx][toIdx] = true;
        history[toIdx][fromIdx] = true;
    }
}
