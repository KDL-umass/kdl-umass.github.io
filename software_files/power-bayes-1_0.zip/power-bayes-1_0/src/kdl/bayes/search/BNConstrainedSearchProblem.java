/**
 * $Id: BNConstrainedSearchProblem.java 273 2009-03-06 16:41:19Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 */

package kdl.bayes.search;

import kdl.bayes.PowerBayesNet;

/**
 * BNConstrainedSearchProblem constrains which edges can be added
 * to BayesNet by looking them in a constraint graph.  If (i,j) in
 * constraint graph, then it is okay to add (i,j) to BayesNet.
 */
public class BNConstrainedSearchProblem extends BNSearchProblem {
    private final boolean[][] constraintGraph;

    public BNConstrainedSearchProblem(PowerBayesNet bn,
                                      boolean[][] constraintGraph) {
        super(bn);
        this.constraintGraph = constraintGraph;
    }

    public BNConstrainedSearchProblem(PowerBayesNet bn,
                                      boolean[][] initialDag,
                                      boolean[][] constraintGraph) {
        super(bn, initialDag);
        this.constraintGraph = constraintGraph;
    }

    protected boolean okayToAddEdge(PowerBayesNet bn, int i, int j) {
        return constraintGraph[i][j] &&
                super.okayToAddEdge(bn, i, j);
    }

    protected boolean okayToRevEdge(PowerBayesNet bn, int i, int j) {
        return constraintGraph[j][i] &&
                super.okayToRevEdge(bn, i, j);
    }
}
