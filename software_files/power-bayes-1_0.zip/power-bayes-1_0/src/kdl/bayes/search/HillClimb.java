/**
 * $Id: HillClimb.java 259 2008-08-29 20:16:45Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 */

package kdl.bayes.search;

import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * HillClimb
 */
public class HillClimb {
    protected static Logger log = Logger.getLogger(HillClimb.class);
    private static double epsilon = 0.00001;


    public static SearchState searchWithRestarts(SearchProblem problem, int numRestarts) {
        SearchState bestState = search(problem);
        double bestScore = problem.getScore(bestState);
        log.info("search 1 concluded. state has score of " + bestScore);
        for (int i = 2; i <= numRestarts; i++) {
            SearchState nextState = search(problem);
            double nextScore = problem.getScore(nextState);
            log.info("search " + i + " concluded. state has score of " + nextScore);
            if (Double.compare(nextScore, bestScore) > 0) {
                bestScore = nextScore;
                bestState = nextState;
            }
        }
        log.info("overall search concluded. best state has score of " + bestScore);
        return bestState;
    }

    public static SearchState search(SearchProblem problem) {
        SearchState currState = problem.getInitialState();

        double currScore = problem.getScore(currState);
        log.debug("Starting search with cost = " + currScore);

        int step = 1;
        while (true) {
            Collection successors = problem.getSuccessors(currState);
            SearchState bestState = null;
            List bestStates = new ArrayList();

            log.debug("Step " + step + " evaluating " + successors.size() + " successors");

            // find best state(s) of successors
            for (Iterator iterator = successors.iterator(); iterator.hasNext();) {
                SearchState succState = (SearchState) iterator.next();


                if (problem.compareStates(succState, bestState) > 0) {
                    bestStates.clear();
                    bestState = succState;
                }

                if (problem.compareStates(succState, bestState) == 0) {
                    bestStates.add(succState);
                }
            }

            if (problem.compareStates(currState, bestState) >= 0) {
                log.debug("Current state is a local minimum with cost = "
                        + currScore + " and the best successor has cost = " +
                        problem.getScore(bestState) + ".  Ending local search...");
                break;
            } else {
                currState = problem.breakTies(bestStates);
                currScore = problem.getScore(bestState);
                currState.makeCurrentState();
                log.debug(currState.toString());
            }
            step++;
        }

        return currState;
    }
}
