/**
 * $Id: PowerBayesNetTest.java 237 2008-04-07 16:54:03Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 *
 */

/**
 * $Id: PowerBayesNetTest.java 237 2008-04-07 16:54:03Z afast $
 */

package kdl.bayes;

import cern.jet.math.Arithmetic;
import junit.framework.TestCase;
import kdl.bayes.util.Util;
import org.apache.log4j.Logger;
import weka.core.Instances;

import java.io.IOException;
import java.io.StringReader;

/**
 * ProxBayesNetTest
 * Author: mhay
 */
public class PowerBayesNetTest extends TestCase {
    protected static Logger log = Logger.getLogger(PowerBayesNetTest.class);
    private double tolerance = 0.0000001;

    private String testInput1 =
            "@relation Grass\n" +
                    "@attribute Cloudy {false,true}\n" +
                    "@attribute Sprinkler {false,true}\n" +
                    "@attribute Rain {false,true}\n" +
                    "@attribute WetGrass {false,true}\n" +
                    "@data\n" +
                    "true,false,true,true\n" +
                    "false,true,false,true";

    private String testInput2 =
            "@relation TestBayesNet\n" +
                    "@attribute A {false,true}\n" +
                    "@attribute B {false,true}\n" +
                    "@attribute C {false,true}\n" +
                    "@data\n" +
                    "true,true,false\n" +
                    "true,true,false\n" +
                    "true,true,false\n" +
                    "true,true,false\n" +
                    "false,false,true\n" +
                    "false,false,true\n" +
                    "false,false,true\n" +
                    "false,false,true\n";

    protected void setUp() throws Exception {
        super.setUp();
        Util.initLog4J();
    }

    public void testBDeu() throws Exception {
        Instances instances = new Instances(new StringReader(testInput1));
        instances.setClassIndex(0);
        PowerBayesNet bn = new PowerBayesNet(instances);
        double expected = Math.log(Math.pow(25, 3) * 30) - Math.log(Math.pow(110, 4));
        assertEquals(expected, bn.logBDeuScore(), tolerance);
    }

    public void testBDeu2() throws Exception {
        Instances instances = new Instances(new StringReader(testInput2));
        instances.setClassIndex(0);
        boolean[][] dag = new boolean[][]{
                {false, false, false},
                {false, false, true},
                {false, false, false}
        };
        PowerBayesNet bn = new PowerBayesNet(instances, dag);
        bn.setEquivalentSampleSize(4);  // math works out nicely with ess = 4

        // expected score is log [(3! 5! 5! / 11!)^2 * 1/25]
        double expectedScore = 0;
        expectedScore += Math.log(Arithmetic.factorial(3));
        expectedScore += Math.log(Arithmetic.factorial(5)) * 2;
        expectedScore -= Math.log(Arithmetic.factorial(11));
        expectedScore *= 2;
        expectedScore -= Math.log(25);
        assertEquals(expectedScore, bn.logBDeuScore(), tolerance);
    }

    public void testGetNeighborAdjList() throws Exception {
        Instances instances = new Instances(new StringReader(testInput2));
        instances.setClassIndex(0);
        boolean[][] dag = new boolean[][]{
                {false, false, false},
                {false, false, true},
                {false, false, false}
        };
        PowerBayesNet bn = new PowerBayesNet(instances, dag);
        boolean[][] constraintGraph = bn.getNeighborsAdjList();

        for (int i = 0; i < constraintGraph.length; i++) {
            for (int j = 0; j < constraintGraph[0].length; j++) {
                if (dag[i][j] == true || dag[j][i] == true) {
                    assertTrue(constraintGraph[i][j]);
                    assertTrue(constraintGraph[j][i]);
                }

                if (dag[i][j] == false && dag[j][i] == false) {
                    assertFalse(constraintGraph[i][j]);
                    assertFalse(constraintGraph[j][i]);
                }
            }
        }
    }

    public void testLogProbability() throws Exception {
        String trainInput =
                "@relation TestBayesNet\n" +
                        "@attribute A {T,F}\n" +
                        "@attribute B {T,F}\n" +
                        "@data\n" +

                        "T,T\n" +
                        "T,T\n" +
                        "T,T\n" +
                        "T,T\n" +

//                        "T,F\n" +

                        "F,T\n" +
                        "F,T\n" +

                        "F,F\n" +
                        "F,F\n" +
                        "F,F\n" +
                        "F,F\n" +

                        "F,F\n" +
                        "F,F\n" +
                        "F,F\n" +
                        "F,F\n";
        Instances instances = new Instances(new StringReader(trainInput));
        boolean[][] dag = new boolean[][]{
                {false, false},
                {true, false},
        };
        instances.setClassIndex(0);
        PowerBayesNet bn = new PowerBayesNet(instances, dag);
        bn.setEquivalentSampleSize(8);


        String testInput =
                "@relation TestBayesNet\n" +
                        "@attribute A {T,F}\n" +
                        "@attribute B {T,F}\n" +
                        "@data\n" +
                        "T,T\n" +
                        "T,F\n" +
                        "F,T\n" +
                        "F,F\n";
        Instances testInstances = new Instances(new StringReader(testInput));

        assertEquals(6.0 / 10 * 10 / 22, Math.exp(bn.logProbability(testInstances.instance(0))), tolerance);
        assertEquals(2.0 / 12 * 12 / 22, Math.exp(bn.logProbability(testInstances.instance(1))), tolerance);
        assertEquals(4.0 / 10 * 10 / 22, Math.exp(bn.logProbability(testInstances.instance(2))), tolerance);
        assertEquals(10.0 / 12 * 12 / 22, Math.exp(bn.logProbability(testInstances.instance(3))), tolerance);
    }

//    public void testLogProbabilityFromFile() throws Exception {
//        String path = "/Users/mhay/mmhc_local/data/";
//        String xmlFile = path + "grass/grass.xml";
//        PowerBayesNet bn = new PowerBayesNet(xmlFile);
//        bn.setEquivalentSampleSize(0);
//
//        String testInput =
//                "@relation Grass\n" +
//                        "@attribute Cloudy {false,true}\n" +
//                        "@attribute Sprinkler {false,true}\n" +
//                        "@attribute Rain {false,true}\n" +
//                        "@attribute WetGrass {false,true}\n" +
//                        "@data\n" +
//                        "false,false,false,false\n" +
//                        "false,false,false,true\n" +
//                        "false,false,true,false\n" +
//                        "false,false,true,true";
//
//
//        Instances testInstances = new Instances(new StringReader(testInput));
//
//        assertEquals(0.5*0.1*0.8*0.99, Math.exp(bn.logProbability(testInstances.instance(0))), tolerance);
//        assertEquals(0.5*0.1*0.8*0.01, Math.exp(bn.logProbability(testInstances.instance(1))), tolerance);
//        assertEquals(0.5*0.1*0.2*0.9, Math.exp(bn.logProbability(testInstances.instance(2))), tolerance);
//        assertEquals(0.5*0.1*0.2*0.1, Math.exp(bn.logProbability(testInstances.instance(3))), tolerance);
//    }

    public void testTopologicalSort() throws IOException {
        Instances instances = new Instances(new StringReader(testInput1));
        instances.setClassIndex(0);
        // E = { (3,2), (3,1), (1,0), (2,0) }
        // partial order: 3 < 2 or 1 < 0
        boolean[][] dag = new boolean[][]{
                {false, false, false, false},
                {true, false, false, false},
                {true, false, false, false},
                {false, true, true, false}
        };
        PowerBayesNet bn = new PowerBayesNet(instances, dag);
        int[] orderedNodes = bn.topologicalSort();
        assertTrue(orderedNodes[0] == 3);
        assertTrue(orderedNodes[1] == 1 && orderedNodes[2] == 2 ||
                orderedNodes[1] == 2 && orderedNodes[2] == 1);
        assertTrue(orderedNodes[3] == 0);
    }

    public void testAncestorMatrix() throws IOException {
        Instances instances = new Instances(new StringReader(testInput1));
        instances.setClassIndex(0);
        // E = { (0,1), (1,2), (2,3) }
        boolean[][] dag = new boolean[][]{
                {false, true, false, false},
                {false, false, true, false},
                {false, false, false, true},
                {false, false, false, false}
        };
        PowerBayesNet bn = new PowerBayesNet(instances, dag);
        boolean[][] expectedMatrix = new boolean[][]{
                {false, true, true, true},
                {false, false, true, true},
                {false, false, false, true},
                {false, false, false, false}
        };
        assertTrue(equalMatrices(expectedMatrix, bn.getAncestorMatrix()));
    }

    public void testPDagChain() throws IOException {
        Instances instances = new Instances(new StringReader(testInput1));
        instances.setClassIndex(0);
        // make a chain
        // E = { (0,1), (1,2), (2,3) }
        // all edges are uncompelled
        boolean[][] dag = new boolean[][]{
                {false, true, false, false},
                {false, false, true, false},
                {false, false, false, true},
                {false, false, false, false}
        };
        PowerBayesNet bn = new PowerBayesNet(instances, dag);

        boolean[][] expectedPDag = new boolean[][]{
                {false, true, false, false},
                {true, false, true, false},
                {false, true, false, true},
                {false, false, true, false}
        };
        assertTrue(equalMatrices(expectedPDag, bn.getPDag()));

    }

    public void testPDagVee() throws IOException {
        Instances instances = new Instances(new StringReader(testInput1));
        instances.setClassIndex(0);
        // make a chain
        // E = { (0,1), (2,1), (2,3) }
        // edges are compelled except (2,3)
        boolean[][] dag = new boolean[][]{
                {false, true, false, false},
                {false, false, false, false},
                {false, true, false, true},
                {false, false, false, false}
        };
        PowerBayesNet bn = new PowerBayesNet(instances, dag);

        boolean[][] expectedPDag = new boolean[][]{
                {false, true, false, false},
                {false, false, false, false},
                {false, true, false, true},
                {false, false, true, false}
        };
        assertTrue(equalMatrices(expectedPDag, bn.getPDag()));

    }

    public void testPDagUncompelledVee() throws IOException {
        Instances instances = new Instances(new StringReader(testInput1));
        instances.setClassIndex(0);
        // make a chain
        // E = { (0,1), (0,2), (2,1), (2,3) }
        // no edges are compelled
        boolean[][] dag = new boolean[][]{
                {false, true, true, false},
                {false, false, false, false},
                {false, true, false, true},
                {false, false, false, false}
        };
        PowerBayesNet bn = new PowerBayesNet(instances, dag);

        // E = { (0,1), (0,2), (1,0), (1,2), (2,0), (2,1), (2,3), (3,2) }
        boolean[][] expectedPDag = new boolean[][]{
                {false, true, true, false},
                {true, false, true, false},
                {true, true, false, true},
                {false, false, true, false}
        };
        assertTrue(equalMatrices(expectedPDag, bn.getPDag()));

    }

    public void testPDagUncompelledVee2() throws IOException {
        Instances instances = new Instances(new StringReader(testInput1));
        instances.setClassIndex(0);
        // make a chain
        // E = { (0,2), (0,3), (1,2), (1,3), (2,3) }
        // all edges are compelled except (2,3)
        boolean[][] dag = new boolean[][]{
                {false, false, true, true},
                {false, false, true, true},
                {false, false, false, true},
                {false, false, false, false}
        };
        PowerBayesNet bn = new PowerBayesNet(instances, dag);

        // add (3,2)
        boolean[][] expectedPDag = new boolean[][]{
                {false, false, true, true},
                {false, false, true, true},
                {false, false, false, true},
                {false, false, true, false}
        };
        assertTrue(equalMatrices(expectedPDag, bn.getPDag()));

    }

    public void testPDagVee3() throws IOException {
        Instances instances = new Instances(new StringReader(testInput1));
        instances.setClassIndex(0);
        // make a chain
        // E = { (0,2), (0,3), (1,2), (2,3) }
        // all edges are compelled
        boolean[][] dag = new boolean[][]{
                {false, false, true, true},
                {false, false, true, false},
                {false, false, false, true},
                {false, false, false, false}
        };
        PowerBayesNet bn = new PowerBayesNet(instances, dag);

        // E = same as above
        boolean[][] expectedPDag = new boolean[][]{
                {false, false, true, true},
                {false, false, true, false},
                {false, false, false, true},
                {false, false, false, false}
        };
        assertTrue(equalMatrices(expectedPDag, bn.getPDag()));

    }

    public void testPDagVee2() throws IOException {
        Instances instances = new Instances(new StringReader(testInput1));
        instances.setClassIndex(0);
        // make a chain
        // E = { (0,2), (1,2), (2,3) }
        // all edges are compelled
        boolean[][] dag = new boolean[][]{
                {false, false, true, false},
                {false, false, true, false},
                {false, false, false, true},
                {false, false, false, false}
        };
        PowerBayesNet bn = new PowerBayesNet(instances, dag);

        // E = same as above
        boolean[][] expectedPDag = new boolean[][]{
                {false, false, true, false},
                {false, false, true, false},
                {false, false, false, true},
                {false, false, false, false}
        };
        assertTrue(equalMatrices(expectedPDag, bn.getPDag()));

    }


    private boolean equalMatrices(boolean[][] expectedMatrix, boolean[][] observed) {
        if (expectedMatrix.length != observed.length) {
            return false;
        }
        for (int i = 0; i < expectedMatrix.length; i++) {
            if (expectedMatrix[i].length != observed[i].length) {
                return false;
            }
            for (int j = 0; j < expectedMatrix[i].length; j++) {
                if (expectedMatrix[i][j] != observed[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }
}
