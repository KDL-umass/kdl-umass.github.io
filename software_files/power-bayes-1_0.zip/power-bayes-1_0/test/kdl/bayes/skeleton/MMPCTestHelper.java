/**
 * $Id: MMPCTestHelper.java 237 2008-04-07 16:54:03Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 *
 */

/**
 * $Id: MMPCTestHelper.java 237 2008-04-07 16:54:03Z afast $
 */

package kdl.bayes.skeleton;

import kdl.bayes.skeleton.util.BayesData;
import kdl.bayes.util.Assert;
import org.apache.log4j.Logger;

import java.util.*;

/**
 * MMPCTestHelper
 * A little wacky, but this is a way of testing the MMPC algorithm
 * without worrying about pvalues and chi-square, etc.  Instead, there
 * is a lookup table of association scores and independence relationships.
 * <p/>
 * It is based on the example in the MMHC paper (see comment in MMHC class)
 */
public class MMPCTestHelper extends BayesData {
    protected static Logger log = Logger.getLogger(MMPCTestHelper.class);

    public final int T;
    public final int C;
    public final int D;
    public final int I;
    Map<String, Double> scores;
    List<String> variables;

    protected int sampleSize = 100;

    private String associationScores = "T;A;;1\n" +
            "T;B;;0\n" +
            "T;C;;.75\n" +
            "T;D;;.7\n" +
            "T;F;;.5\n" +
            "T;H;;0\n" +
            "T;I;;.6\n" +
            "T;K;;.5\n" +
            "\n" +
            "T;B;A;0\n" +
            "T;C;A;.6\n" +
            "T;D;A;.7\n" +
            "T;F;A;.5\n" +
            "T;H;A;0\n" +
            "T;I;A;.6\n" +
            "T;K;A;.5\n" +
            "\n" +
            "T;B;A,D;0\n" +
            "T;C;A,D;.6\n" +
            "T;F;A,D;.9\n" +
            "T;H;A,D;0\n" +
            "T;I;A,D;.5\n" +
            "T;K;A,D;.4\n" +
            "\n" +
            "T;B;A,C,D;0\n" +
            "T;F;A,C,D;0\n" +
            "T;H;A,C,D;0\n" +
            "T;I;A,C,D;.5\n" +
            "T;K;A,C,D;.9\n" +
            "\n" +
            "T;B;A,C,D,I;0\n" +
            "T;F;A,C,D,I;0\n" +
            "T;H;A,C,D,I;0\n" +
            "T;K;A,C,D,I;0\n" +
            "\n" +
            "T;A;C,D;0\n" +
            "T;B;C;0\n" +
            "T;F;C;0\n" +
            "T;K;I;0\n" +
            "T;H;;0";


    public MMPCTestHelper() {
        scores = new HashMap<String, Double>();
        variables = new ArrayList<String>();
        variables.add("T");
        variables.add("A");
        variables.add("B");
        variables.add("C");
        variables.add("D");
        variables.add("F");
        variables.add("H");
        variables.add("I");
        variables.add("K");

        T = getVariableIndex("T");
        C = getVariableIndex("C");
        D = getVariableIndex("D");
        I = getVariableIndex("I");

        String[] lines = associationScores.split("\n");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (line.length() == 0) {
                continue;
            }
            String[] parts = line.split(";");
            int target = getVariableIndex(parts[0]);
            int var = getVariableIndex(parts[1]);
            String[] conditioningSet = parts[2].split(",");
            if (conditioningSet[0].length() == 0) {
                conditioningSet = new String[0];
            }
            int[] condSet = new int[conditioningSet.length];
            for (int j = 0; j < conditioningSet.length; j++) {
                String variable = conditioningSet[j];
                condSet[j] = getVariableIndex(variable);
            }
            String key = makeKey(target, var, condSet);
            double score = Double.parseDouble(parts[3]);
            scores.put(key, score);
        }

        for (Iterator<String> iterator = scores.keySet().iterator(); iterator.hasNext();) {
            String key = iterator.next();
            System.out.println(key + "->" + scores.get(key));
        }
        for (int i = 0; i < variables.size(); i++) {
            System.out.println(i + " : " + variables.get(i));
        }
    }

    public void setIndexes(int xIdx, int tIdx, int[] zIdxs) {
        this.xIdx = xIdx;
        this.tIdx = tIdx;
        this.zIdxs = zIdxs;
    }

    public double[] assoc(double alpha) {
        String key = makeKey(tIdx, xIdx, zIdxs);
//        Assert.condition(scores.containsKey(key), "Key " + key + " not in scores.");
        double score = 1;
        if (!scores.containsKey(key)) {
            log.warn("!!! key=" + key + " score=" + score);
        } else {
            score = scores.get(key);
            log.debug("key=" + key + " score=" + score + " xIdx=" + xIdx + " tIdx=" + tIdx + " zIdxs=" + zIdxs);
        }
        return new double[]{score, -1.0, 1.0, 0, 0};
    }

    public String getName(int variableIdx) {
        return variables.get(variableIdx);
    }

    public String getNames(int[] variableIdxs) {
        return getNames(variableIdxs, " ");
    }

    public String getNames(int[] variableIdxs, String sep) {
        String names = "";
        for (int i = 0; i < variableIdxs.length; i++) {
            int varIdx = variableIdxs[i];
            names += getName(varIdx) + sep;
        }
        return names;
    }

    private int getVariableIndex(String variable) {
        Assert.condition(variables.contains(variable), "Variable " + variable + " not in " + variables);
        return variables.indexOf(variable);
    }

    private String makeKey(int targetIdx, int varIdx, int[] condSetIdxs) {
        String key = variables.get(targetIdx) + ";" + variables.get(varIdx) + ";";
        String[] condSet = new String[condSetIdxs.length];
        for (int i = 0; i < condSetIdxs.length; i++) {
            condSet[i] = variables.get(condSetIdxs[i]);
        }
        Arrays.sort(condSet);
        for (int i = 0; i < condSet.length; i++) {
            key += condSet[i] + ",";
        }
        key += ";";
        return key;
    }

    public int numAttributes() {
        return variables.size();
    }

    public boolean hasZeroDof() {
        return false;
    }

    public void computeStats() {
        log.debug("TEST: (" + getName(tIdx) + ";" + getName(xIdx) + " | " + getNames(zIdxs) + ")");
    }

}
