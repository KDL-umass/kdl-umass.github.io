/**
 * $Id: MMPCTest.java 237 2008-04-07 16:54:03Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 *
 */

/**
 * $Id: MMPCTest.java 237 2008-04-07 16:54:03Z afast $
 */

package kdl.bayes.skeleton;

import junit.framework.TestCase;
import kdl.bayes.skeleton.util.DefaultThreshold;
import kdl.bayes.util.Util;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * MMPCTest
 */
public class MMPCTest extends TestCase {
    protected static Logger log = Logger.getLogger(MMPCTest.class);

    protected void setUp() throws Exception {
        super.setUp();
        Util.initLog4J();
    }

    public void testMMPC() {
        MMPCTestHelper data = new MMPCTestHelper();
        Set<Integer> expectedCPC = new HashSet<Integer>();
        expectedCPC.add(data.C);
        expectedCPC.add(data.D);
        expectedCPC.add(data.I);
        MMPC mmpc = new MMPC(new DefaultThreshold(5000));
        List<Integer> cpc = mmpc.computeCPC(data, data.T);
        log.debug(cpc.toString());
        //assertEquals(expectedCPC, cpc);
        Util.verifyCollections(cpc, expectedCPC);
    }

    public void testMMPCOptimizations() {
        MMPCTestHelper data = new MMPCTestHelper();
        List<Integer> expectedCPC = new ArrayList<Integer>();
        expectedCPC.add(data.C);
        expectedCPC.add(data.D);
        expectedCPC.add(data.I);
        MMPC mmpc = new MMPC(new DefaultThreshold(5000));
        List<Integer> cpc = mmpc.computeCPC(data, data.T, expectedCPC, new ArrayList<Integer>());

        //assertEquals(expectedCPC, cpc);
        Util.verifyCollections(cpc, expectedCPC);
    }

}
