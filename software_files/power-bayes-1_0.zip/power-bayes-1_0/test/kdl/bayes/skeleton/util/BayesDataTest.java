/**
 * $Id: BayesDataTest.java 281 2009-08-15 18:23:09Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 *
 */

/**
 * $Id: BayesDataTest.java 281 2009-08-15 18:23:09Z afast $
 */

package kdl.bayes.skeleton.util;

import junit.framework.TestCase;
import kdl.bayes.util.Assert;
import kdl.bayes.util.StatUtil;
import kdl.bayes.util.Util;
import org.apache.log4j.Logger;
import weka.core.Instances;

import java.io.IOException;
import java.io.StringReader;

/**
 * MMPCDataTest
 * Author: mhay
 */
public class BayesDataTest extends TestCase {
    protected static Logger log = Logger.getLogger(BayesDataTest.class);

    private String testInput =
            "@relation TestData\n" +
                    "@attribute A {T,F}\n" +
                    "@attribute B {T,F}\n" +
                    "@attribute C1 {T,F}\n" +
                    "@attribute C2 {T,F}\n" +
                    "@data\n" +
                    "T,F,T,T\n" +
                    "T,F,T,T\n" +
                    "T,F,T,T\n" +
                    "F,T,T,T\n" +
                    "T,T,F,F\n" +
                    "T,T,F,F\n" +
                    "T,T,F,F\n" +
                    "T,F,F,F\n";

    private String testInput2 =
            "@relation TestData\n" +
                    "@attribute A {T,F}\n" +
                    "@attribute B {T,F}\n" +
                    "@attribute C1 {T,F}\n" +
                    "@attribute C2 {T,F}\n" +
                    "@data\n" +
                    "T,F,T,T\n" +
                    "T,F,T,T\n" +
                    "F,F,T,T\n" +
                    "F,T,T,T\n" +
                    "T,T,T,T\n" +
                    "F,T,F,F\n" +
                    "T,T,F,F\n" +
                    "T,T,F,F\n" +
                    "T,F,F,F\n";

    private String testInput3 =
            "@relation TestData\n" +
                    "@attribute A {T,F}\n" +
                    "@attribute B {T,F}\n" +
                    "@attribute C1 {T,F}\n" +
                    "@attribute C2 {T,F}\n" +
                    "@data\n" +

                    "T,T,T,T\n" +
                    "F,T,T,T\n" +
                    "T,T,T,F\n" +
                    "F,T,T,F\n" +

                    "T,T,F,T\n" +
                    "F,T,F,T\n" +
                    "T,T,F,F\n" +
                    "F,T,F,F\n" +

                    "T,F,T,T\n" +
                    "F,F,T,T\n" +
                    "T,F,T,F\n" +
                    "F,F,T,F\n" +

                    "T,F,F,T\n" +
                    "F,F,F,T\n" +
                    "T,F,F,F\n" +
                    "F,F,F,F\n";

    private String testInput4 =
            "@relation TestData\n" +
                    "@attribute A {T,F,M}\n" +
                    "@attribute B {T,F,M}\n" +
                    "@attribute C {T}\n" +
                    "@data\n" +

                    "T,T,T\n" +
                    "T,F,T\n" +
                    "T,M,T\n" +

                    "F,T,T\n" +
                    "F,F,T\n" +
                    "F,M,T\n" +

                    "M,T,T\n" +
                    "M,F,T\n" +
                    "M,M,T\n";


    protected void setUp() throws Exception {
        super.setUp();
        Util.initLog4J();
    }

    public void testComputeCounts() throws IOException {
        Instances instances = new Instances(new StringReader(testInput));
        BayesData mmpc = new BayesData(instances);
        int[][][] table = mmpc.computeCounts(0, 1, new int[]{2, 3});

        // check the non-zero entries and then zero them out
        assertEquals(2, table.length);
        assertEquals(2, table[0].length);
        assertEquals(4, table[0][0].length);
        assertEquals(3, table[0][1][0]);
        table[0][1][0] = 0;
        assertEquals(1, table[1][0][0]);
        table[1][0][0] = 0;
        assertEquals(3, table[0][0][3]);
        table[0][0][3] = 0;
        assertEquals(1, table[0][1][3]);
        table[0][1][3] = 0;

        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                for (int k = 0; k < table[i][j].length; k++) {
                    int count = table[i][j][k];
                    assertEquals(0, count);
                }
            }
        }

        table = mmpc.computeCounts(0, 1, new int[]{2});

        assertEquals(2, table.length);
        assertEquals(2, table[0].length);
        assertEquals(2, table[0][0].length);

        // check the non-zero entries and then zero them out
        assertEquals(3, table[0][1][0]);
        table[0][1][0] = 0;
        assertEquals(1, table[1][0][0]);
        table[1][0][0] = 0;
        assertEquals(3, table[0][0][1]);
        table[0][0][1] = 0;
        assertEquals(1, table[0][1][1]);
        table[0][1][1] = 0;

        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                for (int k = 0; k < table[i][j].length; k++) {
                    int count = table[i][j][k];
                    assertEquals(0, count);
                }
            }
        }

        table = mmpc.computeCounts(0, 1, new int[]{});

        assertEquals(2, table.length);
        assertEquals(2, table[0].length);
        assertEquals(1, table[0][0].length);

        // check the non-zero entries and then zero them out
        assertEquals(3, table[0][0][0]);
        table[0][0][0] = 0;
        assertEquals(4, table[0][1][0]);
        table[0][1][0] = 0;
        assertEquals(1, table[1][0][0]);
        table[1][0][0] = 0;

        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                for (int k = 0; k < table[i][j].length; k++) {
                    int count = table[i][j][k];
                    assertEquals(0, count);
                }
            }
        }
    }


    public void testComputeDOF() throws IOException {
        Instances instances = new Instances(new StringReader(testInput));
        BayesData mmpc = new BayesData(instances);
        int[][][] counts = mmpc.computeCounts(0, 1, new int[]{2, 3});
        log.info(mmpc.countsToString(counts));
        assertEquals(1, mmpc.computeDegreesOfFreedom(0, 1, new int[]{2, 3}, counts));
        assertEquals(1, mmpc.computeDegreesOfFreedom(1, 0, new int[]{2, 3}, counts));
    }

    public void testComputeDOF2() throws IOException {
        Instances instances = new Instances(new StringReader(testInput2));
        BayesData mmpc = new BayesData(instances);
        int[][][] counts = mmpc.computeCounts(0, 1, new int[]{2, 3});
        assertEquals(2, mmpc.computeDegreesOfFreedom(0, 1, new int[]{2, 3}, counts));
        assertEquals(2, mmpc.computeDegreesOfFreedom(1, 0, new int[]{2, 3}, counts));
    }

    public void testComputeDOF3() throws IOException {
        Instances instances = new Instances(new StringReader(testInput3));
        BayesData mmpc = new BayesData(instances);
        int[][][] counts = mmpc.computeCounts(0, 1, new int[]{2, 3});
        assertEquals(4, mmpc.computeDegreesOfFreedom(0, 1, new int[]{2, 3}, counts));
        assertEquals(4, mmpc.computeDegreesOfFreedom(1, 0, new int[]{2, 3}, counts));
    }

    public void testEffectiveDOF() throws IOException {
        Instances instances = new Instances(new StringReader(testInput4));
        BayesData mmpc = new BayesData(instances);
        int[][][] counts = mmpc.computeCounts(0, 1, new int[]{2});

        long dof = mmpc.computeEffectiveDegreesOfFreedom(0, 1, new int[]{2}, counts);
        assertEquals(4, dof);

        instances = new Instances(new StringReader(testInput2));
        mmpc = new BayesData(instances);
        counts = mmpc.computeCounts(0, 1, new int[]{2, 3});

        dof = mmpc.computeEffectiveDegreesOfFreedom(0, 1, new int[]{2, 3}, counts);
        assertEquals(1, dof);

    }

    public void testCMH() throws IOException {
        int[][][] counts = new int[2][2][5];

        //Rabbits example from Agresti and R documentation.

        counts[0][0][0] = 0;
        counts[1][0][0] = 0;

        counts[0][1][0] = 6;
        counts[1][1][0] = 5;

        counts[0][0][1] = 3;
        counts[1][0][1] = 0;

        counts[0][1][1] = 3;
        counts[1][1][1] = 6;

        counts[0][0][2] = 6;
        counts[1][0][2] = 2;

        counts[0][1][2] = 0;
        counts[1][1][2] = 4;

        counts[0][0][3] = 5;
        counts[1][0][3] = 6;

        counts[0][1][3] = 1;
        counts[1][1][3] = 0;

        counts[0][0][4] = 2;
        counts[1][0][4] = 5;

        counts[0][1][4] = 0;
        counts[1][1][4] = 0;

        BayesData data = new BayesData();
        data.counts = counts;
        data.zIdxs = new int[]{};

        //double[] score = data.cmh(0.05);

        double[] score = new double[]{0, 0, 0, 0, 0};

        log.info(score[1]);
        log.info(score[5]);
        log.info(score[2]);

        log.info(StatUtil.chiSquareP(score[1], 1));

        Assert.condition(StatUtil.equalDoubles(score[5], 0.047, 0.001), "CMH test is incorrect.");
    }
}

