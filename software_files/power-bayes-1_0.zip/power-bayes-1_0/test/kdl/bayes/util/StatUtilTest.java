/**
 * $Id: StatUtilTest.java 281 2009-08-15 18:23:09Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 *
 */
package kdl.bayes.util;

import junit.framework.TestCase;
import kdl.bayes.skeleton.util.BayesData;
import kdl.bayes.skeleton.util.SparseCounts;
import org.apache.log4j.Logger;
import weka.core.Instances;

import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StatUtilTest extends TestCase {

    private static Logger log = Logger.getLogger(StatUtilTest.class);

    protected void setUp() throws Exception {
        Util.initLog4J();
        super.setUp();
    }


    //don't need db to test
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testAverage() throws Exception {
        Double[] list = {new Double(0.1), new Double(0.2), new Double(0.3)};
        double ave = StatUtil.average(list);
        assertEquals(ave, .2, 0.001);

        list = null;
        try {
            ave = StatUtil.average(list);
            assertEquals(1, 0); // i.e. we shouldn't reach this line
        } catch (Exception e) {
            // expected behavior.
            log.info("Got expected exception: " + e);
        }
    }

    public void testBinomialCDF() {
        double pVal = StatUtil.binomialCDF(5, 21, 0.5);
        log.info(pVal);
        Assert.condition(StatUtil.equalDoubles(pVal, 0.0133, 0.001), "Doubles should be equal");
        pVal = StatUtil.binomialCDF(0, 24, (1.0 / 36.0));
        log.info(pVal);
        Assert.condition(StatUtil.equalDoubles(1 - pVal, 0.491, 0.001), "Doubles should be equal");

        pVal = StatUtil.binomialCDF(3, 12, 0.5);
        log.info(pVal);
        Assert.condition(StatUtil.equalDoubles(pVal, 0.07299, 0.001), "Doubles should be equal");

        pVal = StatUtil.binomialCDF(1, 2, 0.5);
        log.info(pVal);
        Assert.condition(StatUtil.equalDoubles(pVal, 0.75, 0.001), "Doubles should be equal");
    }

    public void testChoose() {
        long ch = StatUtil.choose(44, 6);
        log.info(ch);
        Assert.condition(ch == 7059052, "Should be equal");
        Assert.condition(StatUtil.choose(49, 6) == 13983816, "Should be equal");

        Assert.condition(StatUtil.choose(21, 0) == 1, "Anything choose 0 should be 1");
    }

    public void testStuartMaxwell() {
        int[][] counts = new int[][]{{85, 20, 15}, {5, 45, 10}, {5, 10, 5}};
        double stuartMaxwell3way = StatUtil.stuartMaxwell3way(counts);
        log.info(stuartMaxwell3way);
        double chiSquareP = StatUtil.chiSquareP(13.93, 2);
        log.info(chiSquareP);
        Assert.condition(StatUtil.equalDoubles(stuartMaxwell3way, chiSquareP, 0.01), "Should be equal");

        counts = new int[][]{{20, 10, 5}, {3, 30, 15}, {0, 5, 40}};
        Assert.condition(StatUtil.equalDoubles(StatUtil.stuartMaxwell3way(counts), StatUtil.chiSquareP(13.76, 2), 0.001), "Should be equal");

        counts = new int[][]{{0, 9}, {9, 147}};
        Assert.condition(StatUtil.equalDoubles(StatUtil.stuartMaxwell(counts), StatUtil.chiSquareP(13.76, 2), 0.001), "Should be equal");
    }

    public void testStuartMaxwellMultiway() {
        int[][] counts = new int[][]{{85, 20, 15}, {5, 45, 10}, {5, 10, 5}};
        Assert.condition(StatUtil.equalDoubles(StatUtil.stuartMaxwell3way(counts), StatUtil.stuartMaxwellMultiway(counts), 0.001), "Should be equal");

        counts = new int[][]{{20, 10, 5}, {3, 30, 15}, {0, 5, 40}};
        Assert.condition(StatUtil.equalDoubles(StatUtil.stuartMaxwell3way(counts), StatUtil.stuartMaxwellMultiway(counts), 0.001), "Should be equal");

        counts = new int[][]{{144, 33, 84, 126}, {2, 4, 14, 29}, {0, 2, 6, 25}, {0, 0, 1, 5}};
        double value = StatUtil.stuartMaxwellMultiway(counts);
        log.info(value);
        Assert.condition(StatUtil.equalDoubles(271.9222, value, 0.001), "Should be equal");

    }


    /**
     * Tests taken from: http://www.itl.nist.gov/div898/handbook/eda/section3/eda3674.htm
     *
     * @throws Exception
     */
    public void testChiSquareP() throws Exception {
        assertEquals(0.05, StatUtil.chiSquareP(24.996, 15), 0.01);
        assertEquals(0.05, StatUtil.chiSquareP(18.307, 10), 0.01);
    }

    public void testFactorial() {
        Assert.condition(StatUtil.factorial(2) == 2, "Factorial error.");
        Assert.condition(StatUtil.factorial(3) == 6, "Factorial error.");
        Assert.condition(StatUtil.factorial(5) == 120, "Factorial error.");
        Assert.condition(StatUtil.factorial(10) == 3628800, "Factorial error.");


    }

    public void testVariance() throws Exception {
        Double[] list = {new Double(0.1), new Double(0.2), new Double(0.3)};

        double var = StatUtil.variance(list);
        assertEquals(var, .02 / 3, 0.001);
    }

    public void testGStat3D() throws Exception {

        int[][][] counts = new int[2][2][3];
        counts[0][0][0] = 2;
        counts[0][0][1] = 1;
        counts[0][0][2] = 4;

        counts[0][1][0] = 3;
        counts[0][1][1] = 0;
        counts[0][1][2] = 1;

        counts[1][0][0] = 1;
        counts[1][0][1] = 1;
        counts[1][0][2] = 2;

        counts[1][1][0] = 0;
        counts[1][1][1] = 0;
        counts[1][1][2] = 4;

        double g2 = 0;
        g2 += 2 * Math.log(12 / 15.0);
        g2 += 1 * Math.log(1);
        g2 += 4 * Math.log(44 / 30.0);
        g2 += 3 * Math.log(18 / 15.0);
//        g2 += 0 * Math.log(0);
        g2 += 1 * Math.log(11 / 25.0);
        g2 += 1 * Math.log(2);
        g2 += 1 * Math.log(1);
        g2 += 2 * Math.log(22 / 36.0);
//        g2 += 0 * Math.log(/);
//        g2 += 0 * Math.log(/);
        g2 += 4 * Math.log(44 / 30.0);
        g2 *= 2;

        assertEquals(g2, StatUtil.gStatistic(counts), 0.00001);

        String testData =
                "@relation TestData\n" +
                        "@attribute A {0,1}\n" +
                        "@attribute B {0,1}\n" +
                        "@attribute C {0,1,2}\n" +
                        "@data\n" +
                        "0,0,0\n" +
                        "0,0,0\n" +
                        "0,0,1\n" +
                        "0,0,2\n" +
                        "0,0,2\n" +
                        "0,0,2\n" +
                        "0,0,2\n" +
                        "0,1,0\n" +
                        "0,1,0\n" +
                        "0,1,0\n" +
                        "0,1,2\n" +
                        "1,0,0\n" +
                        "1,0,1\n" +
                        "1,0,2\n" +
                        "1,0,2\n" +
                        "1,1,2\n" +
                        "1,1,2\n" +
                        "1,1,2\n" +
                        "1,1,2\n";


        Instances instances = new Instances(new StringReader(testData));
        BayesData data = new BayesData(instances);

        int[] zIdxs = new int[]{2};
        int[][][] counts2 = data.computeCounts(0, 1, zIdxs);
        assertEquals(g2, StatUtil.gStatistic(counts2), 0.00001);

        assertEquals(g2, StatUtil.gStatistic(0, 1, zIdxs, data), 0.00001);

    }

    public void testGStat3DWithZeroRow() throws Exception {
        int[][][] counts = new int[2][2][3];
        counts[0][0][0] = 2;
        counts[0][0][1] = 0;
        counts[0][0][2] = 4;

        counts[0][1][0] = 3;
        counts[0][1][1] = 0;
        counts[0][1][2] = 1;

        counts[1][0][0] = 1;
        counts[1][0][1] = 1;
        counts[1][0][2] = 2;

        counts[1][1][0] = 0;
        counts[1][1][1] = 1;
        counts[1][1][2] = 4;

        double g2 = 0;
        g2 += 2 * Math.log(12 / 15.0);
        // g2 += 0 * Math.log(0);
        g2 += 3 * Math.log(18 / 15.0);
        g2 += 1 * Math.log(2);

        // g2 += 0 * Math.log(0);
        // g2 += 0 * Math.log(0);
        g2 += 1 * Math.log(1);
        g2 += 1 * Math.log(1);


        g2 += 4 * Math.log(44 / 30.0);
        g2 += 1 * Math.log(11 / 25.0);
        g2 += 2 * Math.log(22 / 36.0);
        g2 += 4 * Math.log(44 / 30.0);
        g2 *= 2;

        assertEquals(g2, StatUtil.gStatistic(counts), 0.00001);

        String testData =
                "@relation TestData\n" +
                        "@attribute A {0,1}\n" +
                        "@attribute B {0,1}\n" +
                        "@attribute C {0,1,2}\n" +
                        "@data\n" +
                        "0,0,0\n" +
                        "0,0,0\n" +
                        "0,0,2\n" +
                        "0,0,2\n" +
                        "0,0,2\n" +
                        "0,0,2\n" +
                        "0,1,0\n" +
                        "0,1,0\n" +
                        "0,1,0\n" +
                        "0,1,2\n" +
                        "1,0,0\n" +
                        "1,0,1\n" +
                        "1,0,2\n" +
                        "1,0,2\n" +
                        "1,1,2\n" +
                        "1,1,2\n" +
                        "1,1,2\n" +
                        "1,1,2\n";


        Instances instances = new Instances(new StringReader(testData));
        BayesData data = new BayesData(instances);

        int[] zIdxs = new int[]{2};
        int[][][] counts2 = data.computeCounts(0, 1, zIdxs);
        assertEquals(g2, StatUtil.gStatistic(counts2), 0.00001);

        assertEquals(g2, StatUtil.gStatistic(0, 1, zIdxs, data), 0.00001);

    }

    public void testGStat3DWithZeroMarginal() {
        int[][][] counts = new int[2][2][3];
        counts[0][0][0] = 0;
        counts[0][1][0] = 0;
        counts[1][0][0] = 1;
        counts[1][1][0] = 5;

        counts[0][0][1] = 0;
        counts[0][1][1] = 0;
        counts[1][0][1] = 8;
        counts[1][1][1] = 3;

        counts[0][0][2] = 0;
        counts[0][1][2] = 0;
        counts[1][0][2] = 2;
        counts[1][1][2] = 4;

        /*
        Because of the zero marginals, gStat MUST be 0 --no correlations
         */
        double g2 = 0;
        log.info(StatUtil.gStatistic(counts));
        assertEquals(g2, StatUtil.gStatistic(counts), 0.00001);

    }


    public void testGstat3DWithNoZ() {
        int[][][] counts3D = new int[2][2][1];

        counts3D[0][0][0] = 7;
        counts3D[0][1][0] = 4;
        counts3D[1][0][0] = 4;
        counts3D[1][1][0] = 4;

        double[][] counts2D = new double[2][2];

        counts2D[0][0] = 7;
        counts2D[0][1] = 4;
        counts2D[1][0] = 4;
        counts2D[1][1] = 4;

        double stat1 = StatUtil.gStatistic(counts3D);
        double stat2 = StatUtil.gStatistic(counts2D);

        log.info("3D:" + stat1 + " 2D:" + stat2);

        assertEquals(stat1, stat2, 0.0000001);

    }

    public void testInverseNormalCDF() {
        assertEquals(0.0, StatUtil.inverseStandardNormalCDF(0.5), 0.00001);
        assertEquals(1.5, StatUtil.inverseStandardNormalCDF(0.9332), 0.0001);
        assertEquals(1.64, StatUtil.inverseStandardNormalCDF(0.9495), 0.0001);
        assertEquals(-2.91, StatUtil.inverseStandardNormalCDF(0.00181), 0.001);
        assertEquals(-2.91, StatUtil.inverseStandardNormalCDF(0.00181), 0.001);
    }

    public void testGetCriticalValue() throws Exception {

        double pVal = StatUtil.chiSquareP(7.0, 5);
        log.info("Inital pVal: " + pVal);
        double bestGuess = StatUtil.inverseChiSquareCDF(pVal, 5);
        assertEquals(7.0, bestGuess, 0.01);

        pVal = StatUtil.chiSquareP(15.25, 10);
        log.info("Inital pVal: " + pVal);
        bestGuess = StatUtil.inverseChiSquareCDF(pVal, 10);
        assertEquals(15.25, bestGuess, 0.01);

        assertEquals(0.01, StatUtil.chiSquareP(9.210141451743192, 2), 0.0001);

        pVal = StatUtil.chiSquareP(9.5, 1);
        log.info("Inital pVal: " + pVal);
        bestGuess = StatUtil.inverseChiSquareCDF(pVal, 1);
        assertEquals(9.5, bestGuess, 0.01);

        pVal = StatUtil.chiSquareP(3456, 3456);
        log.info("Inital pVal: " + pVal);
        bestGuess = StatUtil.inverseChiSquareCDF(0.05, 3456);
        log.info("Found pVal: " + StatUtil.chiSquareP(bestGuess, 3456));
        assertEquals(3593.87733850047, bestGuess, 0.01);

        pVal = StatUtil.chiSquareP(4608, 4608);
        log.info("Inital pVal: " + pVal);
        bestGuess = StatUtil.inverseChiSquareCDF(0.05, 4608);
        log.info("Found pVal: " + StatUtil.chiSquareP(bestGuess, 4608));
        assertEquals(4767.035670680271, bestGuess, 0.001);

        pVal = StatUtil.chiSquareP(12419.687702633044, 12288);
        log.info("Inital pVal: " + pVal);
        bestGuess = StatUtil.inverseChiSquareCDF(0.2, 12288);
        log.info("Found pVal: " + StatUtil.chiSquareP(bestGuess, 12288));
        assertEquals(12419.687702633044, bestGuess, 0.001);

        pVal = StatUtil.chiSquareP(27845.632520204977, 27648);
        log.info("Inital pVal: " + pVal);
        bestGuess = StatUtil.inverseChiSquareCDF(0.2, 27648);
        log.info("Found pVal: " + StatUtil.chiSquareP(bestGuess, 27648));
        assertEquals(27845.632520204977, bestGuess, 0.001);
    }

    /**
     * Tests from:
     * <p/>
     * J.�Cohen. Quantitative methods in psychology: A power primer.
     * Psychological Bulletin, 112(1):155�159, 1992.
     * <p/>
     * Additional Tests from:
     * <p/>
     * Cohen, J. Statistical power analysis for the behavioral sciences,
     * 2nd�ed. Lawrence Erlbaum Associates, Inc., 1988. (chapter 7)
     */
    public void testPower() throws Exception {

        assertEquals(0.80, StatUtil.power(0.01, 40, 0.5, 1), 0.1);
        assertEquals(0.80, StatUtil.power(0.01, 130, 0.30, 1), 0.1);
        assertEquals(0.80, StatUtil.power(0.01, 1168, 0.10, 1), 0.1);

        assertEquals(0.80, StatUtil.power(0.01, 55, 0.5, 2), 0.1);
        assertEquals(0.80, StatUtil.power(0.01, 199, 0.30, 5), 0.1);
        assertEquals(0.80, StatUtil.power(0.01, 1546, 0.10, 3), 0.1);

        assertEquals(0.80, StatUtil.power(0.05, 964, 0.10, 2), 0.1);
        assertEquals(0.80, StatUtil.power(0.05, 39, 0.5, 2), 0.1);
        assertEquals(0.80, StatUtil.power(0.05, 133, 0.3, 2), 0.1);

        assertEquals(0.80, StatUtil.power(0.1, 618, 0.1, 1), 0.1);
        assertEquals(0.80, StatUtil.power(0.1, 124, 0.3, 6), 0.1);
        assertEquals(0.80, StatUtil.power(0.1, 42, 0.5, 5), 0.1);

        assertEquals(0.97, StatUtil.power(0.01, 25, 0.9, 1), 0.1);
        assertEquals(0.89, StatUtil.power(0.05, 45, 0.6, 3), 0.1);
        assertEquals(0.10, StatUtil.power(0.05, 50, 0.20, 16), 0.1);

        assertEquals(0.5557557222985495, StatUtil.power(0.2, 2000, 0.1, 192), 0.1);

    }


    public void testMutualInformation() throws Exception {
        int[][][] counts = new int[2][2][3];
        counts[0][0][0] = 2;
        counts[0][0][1] = 1;
        counts[0][0][2] = 4;

        counts[0][1][0] = 3;
        counts[0][1][1] = 0;
        counts[0][1][2] = 1;

        counts[1][0][0] = 1;
        counts[1][0][1] = 1;
        counts[1][0][2] = 2;

        counts[1][1][0] = 0;
        counts[1][1][1] = 0;
        counts[1][1][2] = 4;

        //n_k = [6,2,11]
        //n_ik = {{5,1,5},{1,1,6}}
        //n_jk = {{3,2,6},{3,0,5}


        double g2 = 0;
        g2 += (2.0 / 19) * Math.log(((2.0 / 19.0) * (6.0 / 19.0)) / ((5.0 / 19.0) * (3.0 / 19.0)));
        g2 += (1.0 / 19) * Math.log(((1.0 / 19.0) * (2.0 / 19.0)) / ((1.0 / 19.0) * (2.0 / 19.0)));
        g2 += (4.0 / 19) * Math.log(((4.0 / 19.0) * (11.0 / 19.0)) / ((5.0 / 19.0) * (6.0 / 19.0)));
        g2 += (3.0 / 19) * Math.log(((3.0 / 19.0) * (6.0 / 19.0)) / ((5.0 / 19.0) * (3.0 / 19.0)));
//        g2 += 0 * Math.log(0);
        g2 += (1.0 / 19) * Math.log(((1.0 / 19.0) * (11.0 / 19.0)) / ((5.0 / 19.0) * (5.0 / 19.0)));
        g2 += (1.0 / 19) * Math.log(((1.0 / 19.0) * (6.0 / 19.0)) / ((1.0 / 19.0) * (3.0 / 19.0)));
        g2 += (1.0 / 19) * Math.log(((1.0 / 19.0) * (2.0 / 19.0)) / ((1.0 / 19.0) * (2.0 / 19.0)));
        g2 += (2.0 / 19) * Math.log(((2.0 / 19.0) * (11.0 / 19.0)) / ((6.0 / 19.0) * (6.0 / 19.0)));
//        g2 += 0 * Math.log(/);
//        g2 += 0 * Math.log(/);
        g2 += (4.0 / 19) * Math.log(((4.0 / 19.0) * (11.0 / 19.0)) / ((6.0 / 19.0) * (5.0 / 19.0)));

        assertEquals(g2, StatUtil.mutualInformation(counts), 0.00001);

        //Test matrix
        SparseCounts matrix = new SparseCounts(2, 2, 3);

        for (int i = 0; i < counts.length; i++) {
            for (int j = 0; j < counts[0].length; j++) {
                for (int k = 0; k < counts[0][0].length; k++) {
                    matrix.set(i, j, k, counts[i][j][k]);
                }
            }
        }

        assertEquals(g2, StatUtil.mutualInformation(matrix), 0.00001);

        //Test map
        Map<Integer, Map<Integer, Map<Integer, Integer>>> map = new HashMap<Integer, Map<Integer, Map<Integer, Integer>>>();
        for (int i = 0; i < counts.length; i++) {
            Map<Integer, Map<Integer, Integer>> yMap = new HashMap<Integer, Map<Integer, Integer>>();
            for (int j = 0; j < counts[0].length; j++) {
                Map<Integer, Integer> zMap = new HashMap<Integer, Integer>();
                for (int k = 0; k < counts[0][0].length; k++) {
                    zMap.put(k, counts[i][j][k]);
                }
                yMap.put(j, zMap);
            }
            map.put(i, yMap);
        }

        assertEquals(g2, StatUtil.mutualInformation(map), 0.00001);


    }


    public void testMutualInformationNoZ() throws Exception {
        int[][][] counts3D = new int[2][2][1];

        counts3D[0][0][0] = 7;
        counts3D[0][1][0] = 4;
        counts3D[1][0][0] = 4;
        counts3D[1][1][0] = 4;

        //n = 19
        //n_k = [19]
        //n_ik = {11,8}
        //n_jk = {11,8}

        double mi = 0;
        mi += (7.0 / 19.0) * Math.log((7.0 / 19.0) / ((11.0 / 19.0) * (11.0 / 19.0)));
        mi += (4.0 / 19.0) * Math.log((4.0 / 19.0) / ((11.0 / 19.0) * (8.0 / 19.0)));
        mi += (4.0 / 19.0) * Math.log((4.0 / 19.0) / ((8.0 / 19.0) * (11.0 / 19.0)));
        mi += (4.0 / 19.0) * Math.log((4.0 / 19.0) / ((8.0 / 19.0) * (8.0 / 19.0)));


        double stat1 = StatUtil.mutualInformation(counts3D);
        assertEquals(stat1, mi, 0.000001);


    }

    public void testdofThresholdForEffect() {
        log.info(StatUtil.dofThresholdForEffect(500, 0.2105, 0.95, 0.05));
        log.info(StatUtil.dofThresholdForEffect(1000, 0.1514, 0.95, 0.05));
        log.info(StatUtil.dofThresholdForEffect(2000, 0.1172, 0.95, 0.05));
        log.info(StatUtil.dofThresholdForEffect(5000, 0.0778, 0.95, 0.05));
    }

    public void testPerfectAgreement() {
        int[][] counts = new int[][]{{3, 0, 4}, {0, 5, 0}, {1, 0, 3}};
        List<Integer> listToRemove = StatUtil.checkPerfectAgreement(counts);
        Assert.condition(listToRemove.size() == 1, "SHould only have row 2");
        Assert.condition(listToRemove.contains(1), "Should be perfect agreement.");

        counts = new int[][]{{3, 0, 4, 0}, {0, 5, 0, 0}, {1, 0, 3, 0}, {0, 0, 0, 10}};
        listToRemove = StatUtil.checkPerfectAgreement(counts);
        Assert.condition(listToRemove.size() == 2, "SHould only have 2 rows");
        Assert.condition(listToRemove.contains(1), "Should be perfect agreement.");
        Assert.condition(listToRemove.contains(3), "Should be perfect agreement.");
    }

    public void testFindZeroMarginals() {
        int[][] counts = new int[][]{{0, 0, 0}, {0, 0, 1}, {0, 2, 30}};
        List<Integer> listToRemove = StatUtil.findZeroMarginalRowsColumns(counts);
        Assert.condition(listToRemove.size() == 1, "SHould only have row 2");
        Assert.condition(listToRemove.contains(0), "Should be find row/column 0.");

        counts = new int[][]{{3, 0, 0, 1}, {0, 0, 0, 0}, {1, 0, 0, 0}, {0, 0, 0, 0}};
        listToRemove = StatUtil.checkPerfectAgreement(counts);
        Assert.condition(listToRemove.size() == 1, "SHould only have 2 rows");
        Assert.condition(listToRemove.contains(1), "Should be perfect agreement.");
    }

    public void testShrinkCounts() {
        int[][] counts = new int[][]{{3, 0, 4}, {0, 5, 0}, {1, 0, 3}};
        List<Integer> listToRemove = StatUtil.checkPerfectAgreement(counts);

        int[][] newCounts = StatUtil.shrinkCounts(listToRemove, counts);

        Assert.condition(newCounts.length == 2, "Should only have two rows");
        Assert.condition(newCounts[0].length == 2, "Should only have two rows");

        Assert.condition(newCounts[0][0] == 3, "NO change");
        Assert.condition(newCounts[0][1] == 4, "NO change");
        Assert.condition(newCounts[1][0] == 1, "NO change");
        Assert.condition(newCounts[1][1] == 3, "NO change");

        counts = new int[][]{{3, 0, 4, 0}, {0, 5, 0, 0}, {1, 0, 3, 0}, {0, 0, 0, 10}};
        listToRemove = StatUtil.checkPerfectAgreement(counts);

        newCounts = StatUtil.shrinkCounts(listToRemove, counts);

        Assert.condition(newCounts.length == 2, "Should only have two rows");
        Assert.condition(newCounts[0].length == 2, "Should only have two rows");

        Assert.condition(newCounts[0][0] == 3, "NO change");
        Assert.condition(newCounts[0][1] == 4, "NO change");
        Assert.condition(newCounts[1][0] == 1, "NO change");
        Assert.condition(newCounts[1][1] == 3, "NO change");


    }

}
