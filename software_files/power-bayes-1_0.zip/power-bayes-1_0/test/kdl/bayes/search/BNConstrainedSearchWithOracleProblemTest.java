/**
 * $Id: BNConstrainedSearchWithOracleProblemTest.java 273 2009-03-06 16:41:19Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 *
 */

/**
 * $Id: BNConstrainedSearchWithOracleProblemTest.java 273 2009-03-06 16:41:19Z afast $
 */

package kdl.bayes.search;

import junit.framework.TestCase;
import kdl.bayes.PowerBayesNet;
import kdl.bayes.util.Util;
import org.apache.log4j.Logger;
import weka.core.Instances;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public class BNConstrainedSearchWithOracleProblemTest extends TestCase {

    protected static Logger log = Logger.getLogger(BNConstrainedSearchWithOracleProblemTest.class);
    private boolean[][] dag;
    private PowerBayesNet bnCycleTests;
    private String testInput =
            "@relation TestBayesNet\n" +
                    "@attribute A {false,true}\n" +
                    "@attribute B {false,true}\n" +
                    "@attribute C {false,true}\n" +
                    "@attribute D {false,true}\n" +
                    "@data\n" +
                    "true,true,false,false\n";


    protected void setUp() throws Exception {
        super.setUp();
        Util.initLog4J();
        Instances instances = new Instances(new StringReader(testInput));

        // initial bnCycleTests: E = { (0,1), (1,2) }
        dag = new boolean[][]{
                {false, true, false},
                {false, false, true},
                {false, false, false}
        };
        bnCycleTests = new PowerBayesNet(instances);
    }

    public void testBreakTies() {
        //Need a true dag
        boolean[][] trueDag = new boolean[][]{
                {false, true, true, false},
                {false, false, false, true},
                {false, false, false, true},
                {false, false, false, false}};

        //No actual clauseList
        boolean[][] constraintDag = new boolean[][]{
                {true, true, true, true},
                {true, true, true, true},
                {true, true, true, true},
                {true, true, true, true}
        };

        //First create the search problem
        BNConstrainedSearchWithOracleProblem problem = new BNConstrainedSearchWithOracleProblem(trueDag, bnCycleTests, constraintDag);
        //Then create the initial state
        BNSearchState initialState = new BNSearchState(bnCycleTests);
        initialState.getScore();
        BNSearchState temp1 = new BNSearchState(initialState, 2, 3, BNSearchState.ADD);
        temp1.getScore();
        temp1.makeCurrentState();
        BNSearchState temp2 = new BNSearchState(temp1, 1, 3, BNSearchState.ADD);
        temp2.getScore();
        temp2.makeCurrentState();

        initialState = temp2;

        //Now create a list of tied successor states.
        List<SearchState> tiedStates = new ArrayList<SearchState>();

        BNSearchState rev = new BNSearchState(initialState, 1, 3, BNSearchState.REV);
        BNSearchState del = new BNSearchState(initialState, 2, 3, BNSearchState.DEL);
        BNSearchState add1 = new BNSearchState(initialState, 0, 1, BNSearchState.ADD);
        BNSearchState add2 = new BNSearchState(initialState, 1, 0, BNSearchState.ADD);
        BNSearchState add3 = new BNSearchState(initialState, 0, 3, BNSearchState.ADD);
        BNSearchState add4 = new BNSearchState(initialState, 3, 0, BNSearchState.ADD);

        tiedStates.add(rev);
        tiedStates.add(del);
        tiedStates.add(add1);
        tiedStates.add(add2);
        tiedStates.add(add3);
        tiedStates.add(add4);

        List<SearchState> allowedStates = problem.getAllowedStates(tiedStates);
        assertEquals(5, allowedStates.size());

        List<SearchState> correctStates = new ArrayList<SearchState>();

        correctStates.add(rev);
        correctStates.add(del);
        correctStates.add(add1);
        correctStates.add(add3);
        correctStates.add(add4);

        Util.verifyList(correctStates, allowedStates);
    }
}
