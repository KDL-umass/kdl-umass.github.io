/**
 * $Id: TestSearchProblem.java 259 2008-08-29 20:16:45Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 *
 */

/**
 * $Id: TestSearchProblem.java 259 2008-08-29 20:16:45Z afast $
 */

package kdl.bayes.search;

import kdl.bayes.util.StatUtil;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * TestSearchProblem
 */
public class TestSearchProblem implements SearchProblem {
    private int yMax;
    private int xMax;
    private int[][] searchspace;

    public static final int[][] searchspace1 = new int[][]{
            {0, 1, 4},
            {2, 3, 1}
    };

    public TestSearchProblem() {
        this(searchspace1);
    }

    public TestSearchProblem(int[][] searchspace) {
        this.searchspace = searchspace;
        xMax = this.searchspace.length - 1;
        yMax = this.searchspace[0].length - 1;
    }

    public int compareStates(SearchState state1, SearchState state2) {
        if (state1 == state2) {
            return 0;
        }

        if (state1 == null) {
            return -1;
        }

        if (state2 == null) {
            return 1;
        }


        return Double.compare(getScore(state1), getScore(state2));
    }


    public SearchState getInitialState() {
        return new TestSearchState(0, 0);
    }

    public double getScore(SearchState state) {
        TestSearchState testState = ((TestSearchState) state);
        return searchspace[testState.getCandidateX()][testState.getCandidateY()];
    }

    public Collection getSuccessors(SearchState state) {
        TestSearchState testState = ((TestSearchState) state);
        int x = testState.getX();
        int y = testState.getY();
        Set successors = new HashSet();
        int xLeft = Math.max(x - 1, 0);
        int xRight = Math.min(x + 1, xMax);
        int yLeft = Math.max(y - 1, 0);
        int yRight = Math.min(y + 1, yMax);
        successors.add(new TestSearchState(xLeft, y));
        successors.add(new TestSearchState(xRight, y));
        successors.add(new TestSearchState(x, yLeft));
        successors.add(new TestSearchState(x, yRight));
        return successors;
    }

    public SearchState breakTies(List bestStates) {
        return (SearchState) StatUtil.randomChoice(bestStates);
    }
}
