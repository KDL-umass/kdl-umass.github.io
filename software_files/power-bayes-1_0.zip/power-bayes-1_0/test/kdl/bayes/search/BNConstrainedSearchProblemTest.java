/**
 * $Id: BNConstrainedSearchProblemTest.java 273 2009-03-06 16:41:19Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 *
 */

/**
 * $Id: BNConstrainedSearchProblemTest.java 273 2009-03-06 16:41:19Z afast $
 */

package kdl.bayes.search;

import junit.framework.TestCase;
import kdl.bayes.PowerBayesNet;
import kdl.bayes.util.Util;
import org.apache.log4j.Logger;
import weka.core.Instances;

import java.io.StringReader;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * BNConstrainedSearchProblemTest
 */
public class BNConstrainedSearchProblemTest extends TestCase {

    protected static Logger log = Logger.getLogger(BNSearchProblemTest.class);
    private boolean[][] dag;
    private PowerBayesNet bnCycleTests;
    private String testInput =
            "@relation TestBayesNet\n" +
                    "@attribute A {false,true}\n" +
                    "@attribute B {false,true}\n" +
                    "@attribute C {false,true}\n" +
                    "@data\n" +
                    "true,true,false\n";


    protected void setUp() throws Exception {
        super.setUp();
        Util.initLog4J();
        Instances instances = new Instances(new StringReader(testInput));

        // initial bnCycleTests: E = { (0,1), (1,2) }
        dag = new boolean[][]{
                {false, true, false},
                {false, false, true},
                {false, false, false}
        };
        bnCycleTests = new PowerBayesNet(instances);
    }

    public void testGetSuccessors() {
        // clauseList are in terms of neighbors
        // n(0) = {1}
        // n(1) = {0,2}
        // n(2) = {1}
        // E.g., an edge (0,2) is not allowed b/c 2 is not in n(0)
        boolean[][] constraintGraph = new boolean[][]{
                {false, true, false},
                {true, false, true},
                {false, true, false}
        };
        BNSearchProblem problem =
                new BNConstrainedSearchProblem(bnCycleTests, dag, constraintGraph);

        Set expSuccessors = new HashSet();
        boolean[][] successor;

        // five successors to E = { (0,1), (1,2) }
        // E = { (1,2) }
        // E = { (0,1) }
        // E = { (1,0), (1,2) }
        // E = { (0,1), (2,1) }
        successor = new boolean[][]{
                {false, false, false},
                {false, false, true},
                {false, false, false}
        };
        expSuccessors.add(successor);

        successor = new boolean[][]{
                {false, true, false},
                {false, false, false},
                {false, false, false}
        };
        expSuccessors.add(successor);

        successor = new boolean[][]{
                {false, false, false},
                {true, false, true},
                {false, false, false}
        };
        expSuccessors.add(successor);

        successor = new boolean[][]{
                {false, true, false},
                {false, false, false},
                {false, true, false}
        };
        expSuccessors.add(successor);


        Collection successors = problem.getSuccessors(problem.getInitialState());
        assertEquals(expSuccessors.size(), successors.size());

        for (Iterator succIter = successors.iterator(); succIter.hasNext();) {
            BNSearchState state = (BNSearchState) succIter.next();
            boolean foundInSucessors = false;
            for (Iterator expSuccIter = expSuccessors.iterator(); expSuccIter.hasNext();) {
                boolean[][] expDag = (boolean[][]) expSuccIter.next();
                if (BNSearchProblemTest.equalDags(expDag, state.getDag())) {
                    foundInSucessors = true;
                }
            }
            if (!foundInSucessors) {
                log.debug(BNSearchProblemTest.dagToString(state.getDag()));
            }
            assertTrue(foundInSucessors);
        }
    }
}
