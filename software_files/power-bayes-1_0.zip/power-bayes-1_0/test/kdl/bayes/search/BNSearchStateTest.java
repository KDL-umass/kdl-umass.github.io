/**
 * $Id: BNSearchStateTest.java 273 2009-03-06 16:41:19Z afast $
 *
 * Part of the open-source PowerBayes system
 *   (see LICENSE for copyright and license information).
 *
 */

/**
 * $Id: BNSearchStateTest.java 273 2009-03-06 16:41:19Z afast $
 */

package kdl.bayes.search;

import junit.framework.TestCase;
import kdl.bayes.PowerBayesNet;
import kdl.bayes.util.Util;
import org.apache.log4j.Logger;
import weka.core.Instances;

import java.io.StringReader;


/**
 * BNSearchStateTest
 */
public class BNSearchStateTest extends TestCase {

    protected static Logger log = Logger.getLogger(BNSearchStateTest.class);
    private double tolerance = 0.0000001;
    private Instances instances;
    private String testInput =
            "@relation TestBayesNet\n" +
                    "@attribute A {false,true}\n" +
                    "@attribute B {false,true}\n" +
                    "@attribute C {false,true}\n" +
                    "@data\n" +
                    "true,true,false\n" +
                    "true,true,false\n" +
                    "true,true,false\n" +
                    "true,true,false\n" +
                    "false,false,true\n" +
                    "false,false,true\n" +
                    "false,false,true\n" +
                    "false,false,true\n";

    protected void setUp() throws Exception {
        super.setUp();
        Util.initLog4J();
        instances = new Instances(new StringReader(testInput));
    }

    public void testMultipleScores() {
        // expected dag: E = { (0,1), (2,1) }
        boolean[][] expectedDag = new boolean[][]{
                {false, true, false},
                {false, false, false},
                {false, true, false}
        };
        PowerBayesNet expectedBn = new PowerBayesNet(instances, expectedDag);
        expectedBn.setEquivalentSampleSize(4);  // math works out nicely with ess = 4
        double expectedScore = expectedBn.logBDeuScore();

        // create empty DAG
        PowerBayesNet bn = new PowerBayesNet(instances);
        bn.setEquivalentSampleSize(4);
        BNSearchState initialState = new BNSearchState(bn);

        BNSearchState searchState;

        searchState = new BNSearchState(initialState, 2, 1, BNSearchState.ADD);
        searchState.getScore();
        searchState.makeCurrentState();

        searchState = new BNSearchState(searchState, 0, 1, BNSearchState.ADD);
        searchState.getScore();
        searchState.makeCurrentState();

        searchState = new BNSearchState(searchState, 2, 1, BNSearchState.DEL);
        searchState.getScore();
        searchState.makeCurrentState();

        searchState = new BNSearchState(searchState, 2, 1, BNSearchState.ADD);
        searchState.getScore();
//        searchState.makeCurrentState();

//        searchState = new BNSearchState(2, 1, BNSearchState.ADD);
//        searchState.getScore();
//        searchState.makeCurrentState();
//
//        searchState = new BNSearchState(2, 1, BNSearchState.REV);
//        searchState.getScore();
//        searchState.getScore();

        // After all of these operations, the network has edges (0,1), (1,2)
        assertEquals(expectedScore, searchState.getScore(), tolerance);
        searchState.makeCurrentState();
        assertEquals(expectedScore, searchState.getBayesNet().logBDeuScore(), tolerance);
    }

    public void testScoreAddEdge() {
        // expected dag: E = { (1,2) }
        boolean[][] expectedDag = new boolean[][]{
                {false, false, false},
                {false, false, true},
                {false, false, false}
        };
        PowerBayesNet expectedBn = new PowerBayesNet(instances, expectedDag);
        expectedBn.setEquivalentSampleSize(4);  // math works out nicely with ess = 4
        double expectedScore = expectedBn.logBDeuScore();

        // create empty DAG
        PowerBayesNet bn = new PowerBayesNet(instances);
        bn.setEquivalentSampleSize(4);  // math works out nicely with ess = 4
        BNSearchState initialState = new BNSearchState(bn);

        BNSearchState searchState = new BNSearchState(initialState, 1, 2, BNSearchState.ADD);
        assertEquals(expectedScore, searchState.getScore(), tolerance);

        // For this particular data, the score for adding edge 0,2 should be the
        // same as adding edge 1,2
        BNSearchState anotherSearchState = new BNSearchState(initialState, 0, 2, BNSearchState.ADD);
        assertEquals(expectedScore, anotherSearchState.getScore(), tolerance);
    }

    public void testScoreAddThenDelEdge() {
        // expected dag: E = { }
        boolean[][] expectedDag = new boolean[][]{
                {false, false, false},
                {false, false, false},
                {false, false, false}
        };
        PowerBayesNet expectedBn = new PowerBayesNet(instances, expectedDag);
        expectedBn.setEquivalentSampleSize(4);  // math works out nicely with ess = 4
        double expectedScore = expectedBn.logBDeuScore();

        // create empty DAG
        PowerBayesNet bn = new PowerBayesNet(instances);
        bn.setEquivalentSampleSize(4);
        BNSearchState initialState = new BNSearchState(bn);

        BNSearchState searchState = new BNSearchState(initialState, 1, 2, BNSearchState.ADD);
        searchState.getScore();
        searchState.makeCurrentState();
        BNSearchState anotherSearchState = new BNSearchState(searchState, 1, 2, BNSearchState.DEL);

        // The score after adding then deleting edge 0,2 should be the same
        // the original network
        assertEquals(expectedScore, anotherSearchState.getScore(), tolerance);
        anotherSearchState.makeCurrentState();
        assertEquals(expectedScore, anotherSearchState.getBayesNet().logBDeuScore(), tolerance);
    }

    public void testScoreDelEdge() {
        // expected dag: E = { }
        boolean[][] expectedDag = new boolean[][]{
                {false, false, false},
                {false, false, false},
                {false, false, false}
        };
        PowerBayesNet expectedBn = new PowerBayesNet(instances, expectedDag);
        expectedBn.setEquivalentSampleSize(4);  // math works out nicely with ess = 4
        double expectedScore = expectedBn.logBDeuScore();

        // create DAG with (1,2)

        boolean[][] learnedDag = new boolean[][]{
                {false, false, false},
                {false, false, true},
                {false, false, false}
        };

        PowerBayesNet bn = new PowerBayesNet(instances, learnedDag);
        bn.setEquivalentSampleSize(4);  // math works out nicely with ess = 4
        BNSearchState initialState = new BNSearchState(bn);

        BNSearchState searchState = new BNSearchState(initialState, 1, 2, BNSearchState.DEL);
        assertEquals(expectedScore, searchState.getScore(), tolerance);
    }

//    public void testScoreDoesNotChangeBayesNet() {
//        // expected dag: E = { (0,1), (2,1) }
//        boolean[][] expectedDag = new boolean[][]{
//                {false, true, false},
//                {false, false, false},
//                {false, true, false}
//        };
//        PowerBayesNet expectedBn = new PowerBayesNet(instances, expectedDag);
//        expectedBn.setEquivalentSampleSize(4);
//        double expectedScore = expectedBn.logProbability(instances);
//
//        BNSearchState initialState = new BNSearchState(expectedBn);
//
//        log.debug("Parents (in order) of variable 0 before: [" + expectedBn.getParent(1, 0) +
//                "," + expectedBn.getParent(1, 1) + "]");
//
//        BNSearchState searchState = new BNSearchState(initialState, 0, 1, BNSearchState.DEL);
//        searchState.getScore();
//
//        PowerBayesNet bayesNet = searchState.getBayesNet();
//        log.debug("Parents (in order) of variable 0 after: [" + bayesNet.getParent(1, 0) +
//                "," + bayesNet.getParent(1, 1) + "]");
//
//        double score = searchState.getBayesNet().logProbability(instances);
//        assertEquals(expectedScore, score, tolerance);
//    }

    public void testScoreReverseEdge() {
        boolean[][] learnedDag = new boolean[][]{
                {false, false, false},
                {false, false, true},
                {false, false, false}
        };


        PowerBayesNet bn = new PowerBayesNet(instances, learnedDag);
        bn.setEquivalentSampleSize(4);  // math works out nicely with ess = 4
        BNSearchState initialState = new BNSearchState(bn);

        double expectedScore = bn.logBDeuScore();

        BNSearchState searchState = new BNSearchState(initialState, 1, 2, BNSearchState.REV);
        assertEquals(expectedScore, searchState.getScore(), tolerance);
    }
}
