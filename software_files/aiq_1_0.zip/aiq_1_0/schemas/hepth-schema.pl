/**
 * $Id: hepth-schema.pl 36 2008-04-04 15:29:08Z afast $
 *
 * Part of the open-source AIQUE system
 *   (see LICENSE for copyright and license information).
 *
 */

/* 
 * hepth-schema.pl contains the schema predicates for the hep_th database.
 */


%Item declaration.
item(journal).
item(paper).
item(submits).
item(author).
item(credited).
item(citing-paper).

%Variable declaration.
itemVar(paper-pub-date, paper).
itemVar(submit-date, submits).
itemVar(cite-year, citing-paper).
itemVar(credit-year, credited).

itemVar(journal-name, journal).
itemVar(author-name, author).
itemVar(paper-title, paper).


%Relations among items. For now these encode the relations we need to do temporal analysis.
baseRelated(journal, paper, one, many).
baseRelated(paper, submits, one, many).
baseRelated(author, submits, one, many).
baseRelated(author, credited, one, many).
baseRelated(citing-paper, credited, one, many).
baseRelated(paper, citing-paper, one, many).

%Temporal Declarations

%Possible base items.
itemExtent(paper, 7300). %papers last 20 years
itemExtent(author, 7300). %authors publish for 20 years
itemExtent(citing-paper, 7300). %papers last 20 years
itemExtent(journal, 14600). %journals act for 40 years

relationFrequency(journal, paper, 7).
relationFrequency(paper, citing-paper, 7).
relationFrequency(citing-paper, credited, 7).
relationFrequency(paper, submits, 1000).
relationFrequency(author, submits, 30).
relationFrequency(author, credited, 14).

%Define causes
setAsTaboo(exists(paper), _).
setAsTaboo(exists(citing-paper), _).

setAsTaboo(exists(submits), _).
setAsTaboo(agg(submit-date), _).
setAsTaboo(exists(credited), _).
setAsTaboo(agg(credit-year), _).