import unittest

@unittest.skip("this class is a placeholder so that IntelliJ will enable running the entire test/ directory")
class MyTestCase(unittest.TestCase):
    pass
